# CORE Theory v5.0 — Complete Codebase

**Glassmorphic Calisthenics OS**

## Tech Stack
- **React 18** + Vite
- **React Router v6** — client-side routing
- **Tailwind CSS** — utility classes
- **Vanilla Canvas API** — live animated fitness background
- **Web Speech API** — coach narration (built-in, no library)
- **Anthropic API** — AI Coach (Pro-Coach 2.0)

---

## Project Structure

```
coretheory/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── .env.example              ← copy to .env and add your API key
└── src/
    ├── main.jsx
    ├── App.jsx               ← routes + AuthContext + LiveBackground
    ├── index.css             ← all design tokens, glassmorphic utilities
    ├── components/
    │   ├── Layout.jsx        ← navbar + outlet wrapper
    │   ├── Navbar.jsx        ← glassmorphic nav, mobile hamburger
    │   ├── LiveBackground.jsx← canvas: auroras, grid, particles, fitness icons
    │   └── MuscleAvatar.jsx  ← SVG body with crimson/teal muscle glow
    ├── data/
    │   └── exercises.js      ← all 36+ exercises with cues and metadata
    └── pages/
        ├── Home.jsx          ← hero, features, founder, science sections
        ├── Exercises.jsx     ← filter grid, 36 exercise cards
        ├── ExerciseDetail.jsx← avatar glow + coach narration + cues
        ├── Coach.jsx         ← Pro-Coach AI 2.0 chat (Anthropic API)
        ├── CoreAI.jsx        ← AI hub with today's exercises
        ├── NutritionPlus.jsx ← macro calculator + hydration tracker
        ├── Auth.jsx          ← login + 3-step signup + ID upload
        ├── WomensDashboard.jsx   ← cycle-synced training, 4 phases
        ├── AdaptiveDashboard.jsx ← seated + low-impact exercises
        ├── ExecutiveDashboard.jsx← 9-5 office routines + break tracker
        ├── AvatarPage.jsx    ← 3D avatar placeholder
        ├── Pricing.jsx       ← 4 pricing tiers
        └── Misc.jsx          ← shared components for Exec/Pricing/Avatar
```

---

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Add your Anthropic API key (for AI Coach)
cp .env.example .env
# Edit .env: VITE_ANTHROPIC_API_KEY=sk-ant-your-key-here

# 3. Start dev server
npm run dev

# 4. Build for production
npm run build
```

---

## Pages & Routes

| Route | Page |
|-------|------|
| `/` | Home — hero, founder, science |
| `/exercises` | Exercise Library — filter grid |
| `/exercise/:id` | Exercise Detail — avatar glow + narration |
| `/coach` | Pro-Coach AI 2.0 — Anthropic chat |
| `/core-ai` | Core AI Hub |
| `/nutrition-plus` | Macro Calculator + Meal Prep |
| `/dashboard/executive` | Executive 9-5 Dashboard |
| `/dashboard/womens` | **Women's Dashboard** — cycle-synced |
| `/dashboard/disabled` | **Adaptive Dashboard** — seated/low-impact |
| `/avatar` | Avatar Engine |
| `/pricing` | Pricing tiers |
| `/auth` | Sign In / Sign Up (3-step with ID upload) |

---

## Authentication & Profile Routing

The Auth page has a **3-step signup flow**:

1. **Details** — name, email, password
2. **Profile selection** — General / Female / Adaptive athlete
3. **ID upload** (Adaptive only) — disability ID card or certification

After login, users are **auto-routed by profile**:
- `general` → `/exercises`
- `female` → `/dashboard/womens`
- `disabled` → `/dashboard/disabled`

**Demo login:** Use any email. Include "female" or "disabled" in the email to test those dashboards.

---

## Live Animated Background

`LiveBackground.jsx` renders a full-screen Canvas animation with:
- **Moving perspective grid** — slow scrolling grid lines
- **Aurora nebulas** — crimson + teal radial gradients that pulse and drift
- **Floating fitness icons** — dumbbells, kettlebells, barbells, running figure, pullup bar
- **Particles** — crimson, teal, and white micro-particles drifting upward
- **Vignette** — dark edge to keep foreground readable

Performance: ~0.1% CPU on modern hardware. Canvas is `position: fixed; z-index: -1`.

---

## AI Coach Setup

Add your key to `.env`:
```
VITE_ANTHROPIC_API_KEY=sk-ant-api03-...
```

Without a key, the Coach runs in **demo mode** — it acknowledges messages and explains how to enable live coaching. With a key, it uses `claude-opus-4-6` with a sports-science system prompt.

---

## Design System

All design tokens are in `src/index.css`:

```css
--crimson: #e5193e        /* primary muscle / CTAs */
--teal: #00d4d4           /* secondary muscle / teal accents */
--bg: #08080f             /* canvas bg */
--glass: rgba(255,255,255,0.04)   /* card background */
--font-display: 'Orbitron'        /* numbers, logo, stats */
--font-heading: 'Syne'            /* headings, labels, buttons */
--font-body: 'DM Sans'            /* body copy */
```

Utility classes: `.glass`, `.glass-md`, `.btn`, `.btn-crimson`, `.btn-ghost`, `.btn-teal`, `.badge`, `.badge-crimson`, `.badge-teal`, `.card-lift`, `.gradient-text`, `.anim-fade-up`.

---

## Compatible Tools

Paste this codebase into:
- **Cursor** — full AI editing
- **Bolt.new** — paste and deploy
- **Replit** — host + edit
- **GitHub + Vercel** — push and deploy in 1 click
- **StackBlitz** — browser-based

---

Built by CORE Theory · v5.0
