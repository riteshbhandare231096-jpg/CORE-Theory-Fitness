import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { createContext, useContext, useState } from 'react'
import Layout from './components/Layout'
import LiveBackground from './components/LiveBackground'
import Home from './pages/Home'
import Exercises from './pages/Exercises'
import ExerciseDetail from './pages/ExerciseDetail'
import Coach from './pages/Coach'
import CoreAI from './pages/CoreAI'
import NutritionPlus from './pages/NutritionPlus'
import ExecutiveDashboard from './pages/ExecutiveDashboard'
import WomensDashboard from './pages/WomensDashboard'
import AdaptiveDashboard from './pages/AdaptiveDashboard'
import AvatarPage from './pages/AvatarPage'
import Pricing from './pages/Pricing'
import Auth from './pages/Auth'

export const AuthContext = createContext(null)
export function useAuth() { return useContext(AuthContext) }

export default function App() {
  const [user, setUser] = useState(null)

  return (
    <AuthContext.Provider value={{ user, setUser }}>
    <LiveBackground />
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="exercises" element={<Exercises />} />
          <Route path="exercise/:id" element={<ExerciseDetail />} />
          <Route path="coach" element={<Coach />} />
          <Route path="core-ai" element={<CoreAI />} />
          <Route path="nutrition-plus" element={<NutritionPlus />} />
          <Route path="dashboard/executive" element={<ExecutiveDashboard />} />
          <Route path="dashboard/womens" element={<WomensDashboard />} />
          <Route path="dashboard/disabled" element={<AdaptiveDashboard />} />
          <Route path="avatar" element={<AvatarPage />} />
          <Route path="pricing" element={<Pricing />} />
          <Route path="auth" element={<Auth />} />
        </Route>
      </Routes>
    </BrowserRouter>
    </AuthContext.Provider>
  )
}
