import { Outlet } from 'react-router-dom'
import Navbar from './Navbar'

export default function Layout() {
  return (
    <>
      <Navbar />
      <main style={{ paddingTop: 60, minHeight: '100vh' }}>
        <Outlet />
      </main>
    </>
  )
}
