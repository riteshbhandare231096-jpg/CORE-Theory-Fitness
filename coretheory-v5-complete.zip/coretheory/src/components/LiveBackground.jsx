import { useEffect, useRef } from 'react'

/* Floating fitness icon shapes */
const ICONS = [
  // Dumbbell
  (ctx, x, y, s, a) => {
    ctx.save()
    ctx.globalAlpha = a
    ctx.translate(x, y)
    ctx.rotate(s.rot)
    ctx.strokeStyle = s.color
    ctx.lineWidth = 1.5
    ctx.lineCap = 'round'
    // bar
    ctx.beginPath()
    ctx.moveTo(-14, 0); ctx.lineTo(14, 0); ctx.stroke()
    // left plates
    ctx.beginPath()
    ctx.moveTo(-14, -5); ctx.lineTo(-14, 5); ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(-10, -7); ctx.lineTo(-10, 7); ctx.stroke()
    // right plates
    ctx.beginPath()
    ctx.moveTo(14, -5); ctx.lineTo(14, 5); ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(10, -7); ctx.lineTo(10, 7); ctx.stroke()
    ctx.restore()
  },
  // Kettlebell
  (ctx, x, y, s, a) => {
    ctx.save()
    ctx.globalAlpha = a
    ctx.translate(x, y)
    ctx.rotate(s.rot)
    ctx.strokeStyle = s.color
    ctx.lineWidth = 1.5
    // body
    ctx.beginPath()
    ctx.arc(0, 4, 9, 0, Math.PI * 2)
    ctx.stroke()
    // handle
    ctx.beginPath()
    ctx.arc(0, -4, 6, Math.PI, 0)
    ctx.stroke()
    ctx.restore()
  },
  // Hexagon (weight plate)
  (ctx, x, y, s, a) => {
    ctx.save()
    ctx.globalAlpha = a
    ctx.translate(x, y)
    ctx.rotate(s.rot)
    ctx.strokeStyle = s.color
    ctx.lineWidth = 1.2
    ctx.beginPath()
    for (let i = 0; i < 6; i++) {
      const angle = (Math.PI / 3) * i
      const px = Math.cos(angle) * 10
      const py = Math.sin(angle) * 10
      i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)
    }
    ctx.closePath()
    ctx.stroke()
    ctx.beginPath()
    ctx.arc(0, 0, 3, 0, Math.PI * 2)
    ctx.stroke()
    ctx.restore()
  },
  // Barbell
  (ctx, x, y, s, a) => {
    ctx.save()
    ctx.globalAlpha = a
    ctx.translate(x, y)
    ctx.rotate(s.rot)
    ctx.strokeStyle = s.color
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(-20, 0); ctx.lineTo(20, 0); ctx.stroke()
    [-18, -14, 14, 18].forEach(rx => {
      ctx.beginPath()
      ctx.moveTo(rx, -6); ctx.lineTo(rx, 6); ctx.stroke()
    })
    ctx.restore()
  },
  // Running figure
  (ctx, x, y, s, a) => {
    ctx.save()
    ctx.globalAlpha = a
    ctx.translate(x, y)
    ctx.rotate(s.rot)
    ctx.strokeStyle = s.color
    ctx.lineWidth = 1.4
    ctx.lineCap = 'round'
    // head
    ctx.beginPath()
    ctx.arc(0, -12, 3.5, 0, Math.PI * 2)
    ctx.stroke()
    // body
    ctx.beginPath()
    ctx.moveTo(0, -8); ctx.lineTo(0, 2); ctx.stroke()
    // arms
    ctx.beginPath()
    ctx.moveTo(-7, -3); ctx.lineTo(5, -6); ctx.stroke()
    // legs
    ctx.beginPath()
    ctx.moveTo(0, 2); ctx.lineTo(-6, 10); ctx.lineTo(-8, 16); ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(0, 2); ctx.lineTo(6, 10); ctx.lineTo(4, 16); ctx.stroke()
    ctx.restore()
  },
  // Pullup bar
  (ctx, x, y, s, a) => {
    ctx.save()
    ctx.globalAlpha = a
    ctx.translate(x, y)
    ctx.rotate(s.rot)
    ctx.strokeStyle = s.color
    ctx.lineWidth = 1.5
    // bar
    ctx.beginPath()
    ctx.moveTo(-16, 0); ctx.lineTo(16, 0); ctx.stroke()
    // person hanging
    ctx.beginPath()
    ctx.moveTo(-5, 0); ctx.lineTo(-5, 6)
    ctx.moveTo(5, 0); ctx.lineTo(5, 6)
    ctx.lineTo(0, 6); ctx.lineTo(-5, 6); ctx.stroke()
    ctx.beginPath()
    ctx.arc(0, 10, 4, 0, Math.PI * 2); ctx.stroke()
    ctx.restore()
  },
]

function createParticle(W, H) {
  const colors = ['rgba(229,25,62,', 'rgba(0,212,212,', 'rgba(255,255,255,']
  const colorBase = colors[Math.floor(Math.random() * colors.length)]
  return {
    x: Math.random() * W,
    y: Math.random() * H,
    vx: (Math.random() - 0.5) * 0.4,
    vy: -Math.random() * 0.5 - 0.1,
    r: Math.random() * 2 + 0.5,
    alpha: Math.random() * 0.5 + 0.1,
    life: 1,
    decay: Math.random() * 0.003 + 0.001,
    color: colorBase,
  }
}

function createIcon(W, H) {
  const colors = [
    'rgba(229,25,62,0.18)',
    'rgba(0,212,212,0.14)',
    'rgba(255,255,255,0.08)',
    'rgba(229,25,62,0.12)',
  ]
  return {
    x: Math.random() * W,
    y: Math.random() * H,
    vx: (Math.random() - 0.5) * 0.18,
    vy: -Math.random() * 0.15 - 0.05,
    rot: Math.random() * Math.PI * 2,
    rotV: (Math.random() - 0.5) * 0.004,
    color: colors[Math.floor(Math.random() * colors.length)],
    type: Math.floor(Math.random() * ICONS.length),
    alpha: Math.random() * 0.6 + 0.2,
    scale: Math.random() * 0.7 + 0.6,
  }
}

export default function LiveBackground() {
  const canvasRef = useRef(null)
  const frameRef = useRef(null)
  const stateRef = useRef({
    particles: [],
    icons: [],
    aurora: { t: 0 },
    grid: { offset: 0 },
  })

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    let W, H

    function resize() {
      W = canvas.width = window.innerWidth
      H = canvas.height = window.innerHeight
      // init icons
      stateRef.current.icons = Array.from({ length: 12 }, () => createIcon(W, H))
    }
    resize()
    window.addEventListener('resize', resize)

    function drawAurora(t) {
      // Multi-layer aurora nebulas
      const layers = [
        { x: W * 0.12, y: H * 0.22, rx: W * 0.45, ry: H * 0.3, hue: 'crimson', speed: 0.0003 },
        { x: W * 0.85, y: H * 0.78, rx: W * 0.5, ry: H * 0.35, hue: 'teal', speed: 0.0002 },
        { x: W * 0.5,  y: H * 0.5,  rx: W * 0.35, ry: H * 0.25, hue: 'mid', speed: 0.0004 },
      ]

      layers.forEach(l => {
        const pulse = Math.sin(t * l.speed * 1000 + l.x) * 0.3 + 0.7
        const grd = ctx.createRadialGradient(
          l.x + Math.sin(t * l.speed * 800) * 60, l.y + Math.cos(t * l.speed * 600) * 40,
          0,
          l.x, l.y, Math.max(l.rx, l.ry)
        )

        if (l.hue === 'crimson') {
          grd.addColorStop(0,   `rgba(229,25,62,${0.08 * pulse})`)
          grd.addColorStop(0.4, `rgba(180,10,40,${0.04 * pulse})`)
          grd.addColorStop(1,   'rgba(229,25,62,0)')
        } else if (l.hue === 'teal') {
          grd.addColorStop(0,   `rgba(0,212,212,${0.065 * pulse})`)
          grd.addColorStop(0.4, `rgba(0,160,180,${0.03 * pulse})`)
          grd.addColorStop(1,   'rgba(0,212,212,0)')
        } else {
          grd.addColorStop(0,   `rgba(100,0,180,${0.035 * pulse})`)
          grd.addColorStop(1,   'rgba(100,0,180,0)')
        }

        ctx.save()
        ctx.scale(1, l.ry / l.rx)
        ctx.beginPath()
        ctx.arc(l.x, l.y * (l.rx / l.ry), l.rx, 0, Math.PI * 2)
        ctx.fillStyle = grd
        ctx.fill()
        ctx.restore()
      })
    }

    function drawGrid(offset) {
      const sz = 56
      ctx.save()
      ctx.strokeStyle = 'rgba(255,255,255,0.025)'
      ctx.lineWidth = 0.5

      const cols = Math.ceil(W / sz) + 1
      const rows = Math.ceil(H / sz) + 1
      const ox = (offset * 0.3) % sz
      const oy = (offset * 0.15) % sz

      for (let i = 0; i <= cols; i++) {
        ctx.beginPath()
        ctx.moveTo(i * sz - ox, 0)
        ctx.lineTo(i * sz - ox, H)
        ctx.stroke()
      }
      for (let j = 0; j <= rows; j++) {
        ctx.beginPath()
        ctx.moveTo(0, j * sz - oy)
        ctx.lineTo(W, j * sz - oy)
        ctx.stroke()
      }
      ctx.restore()
    }

    function tick(t) {
      const st = stateRef.current

      ctx.clearRect(0, 0, W, H)

      // Base gradient
      const bg = ctx.createLinearGradient(0, 0, 0, H)
      bg.addColorStop(0, '#06060f')
      bg.addColorStop(0.5, '#08080f')
      bg.addColorStop(1, '#060610')
      ctx.fillStyle = bg
      ctx.fillRect(0, 0, W, H)

      // Grid
      st.grid.offset += 0.4
      drawGrid(st.grid.offset)

      // Auroras
      drawAurora(t)

      // Particles
      if (Math.random() < 0.35) {
        st.particles.push(createParticle(W, H))
      }
      st.particles = st.particles.filter(p => p.life > 0)
      st.particles.forEach(p => {
        p.x += p.vx
        p.y += p.vy
        p.life -= p.decay
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fillStyle = `${p.color}${(p.life * p.alpha).toFixed(2)})`
        ctx.fill()
      })

      // Floating icons
      st.icons.forEach((ic, idx) => {
        ic.x += ic.vx
        ic.y += ic.vy
        ic.rot += ic.rotV
        // wrap
        if (ic.y < -40)  { ic.y = H + 40; ic.x = Math.random() * W }
        if (ic.x < -40)  ic.x = W + 40
        if (ic.x > W+40) ic.x = -40

        const floatA = ic.alpha * (0.7 + 0.3 * Math.sin(t * 0.0004 + idx * 1.2))
        ctx.save()
        ctx.scale(ic.scale, ic.scale)
        ICONS[ic.type](ctx, ic.x / ic.scale, ic.y / ic.scale, ic, floatA)
        ctx.restore()
      })

      // Vignette
      const vgrd = ctx.createRadialGradient(W/2, H/2, H*0.2, W/2, H/2, H*0.85)
      vgrd.addColorStop(0, 'rgba(0,0,0,0)')
      vgrd.addColorStop(1, 'rgba(0,0,8,0.65)')
      ctx.fillStyle = vgrd
      ctx.fillRect(0, 0, W, H)

      frameRef.current = requestAnimationFrame(tick)
    }

    frameRef.current = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(frameRef.current)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: -1,
        pointerEvents: 'none',
        display: 'block',
      }}
    />
  )
}
