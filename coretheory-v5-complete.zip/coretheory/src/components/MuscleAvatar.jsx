/**
 * MuscleAvatar
 * Props:
 *   primary   — array of muscle keys (glow crimson)
 *   secondary — array of muscle keys (glow teal)
 *   size      — number (default 320)
 *
 * Muscle keys: chest, triceps, biceps, lats, core, shoulders,
 *   upper-back, lower-back, quads, hamstrings, glutes, calves,
 *   forearms, hip-flexors, adductors, traps, rhomboids, rear-delts,
 *   neck, spine
 */

const MUSCLE_COLORS = {
  crimson: '#e5193e',
  teal: '#00d4d4',
  rest: 'rgba(255,255,255,0.07)',
  restStroke: 'rgba(255,255,255,0.12)',
}

function getColor(key, primary = [], secondary = []) {
  if (primary.map(k => k.toLowerCase()).includes(key)) return { fill: MUSCLE_COLORS.crimson, anim: 'muscleGlow' }
  if (secondary.map(k => k.toLowerCase()).includes(key)) return { fill: MUSCLE_COLORS.teal, anim: 'tealGlow' }
  return { fill: MUSCLE_COLORS.rest, anim: null }
}

export default function MuscleAvatar({ primary = [], secondary = [], size = 320 }) {
  const s = (key) => getColor(key, primary, secondary)

  const MuscleGroup = ({ id, d, style = {} }) => {
    const { fill, anim } = s(id)
    return (
      <path
        d={d}
        fill={fill}
        stroke={fill === MUSCLE_COLORS.rest ? MUSCLE_COLORS.restStroke : fill}
        strokeWidth="0.5"
        strokeOpacity="0.6"
        style={{
          transition: 'fill 0.4s ease',
          animation: anim ? `${anim} 2s ease-in-out infinite` : 'none',
          ...style,
        }}
      />
    )
  }

  return (
    <div style={{ position: 'relative', width: size, height: size * 1.6 }}>
      <style>{`
        @keyframes muscleGlow {
          0%,100% { filter: drop-shadow(0 0 5px rgba(229,25,62,0.6)); }
          50%      { filter: drop-shadow(0 0 14px rgba(229,25,62,0.95)); }
        }
        @keyframes tealGlow {
          0%,100% { filter: drop-shadow(0 0 4px rgba(0,212,212,0.55)); }
          50%      { filter: drop-shadow(0 0 10px rgba(0,212,212,0.85)); }
        }
      `}</style>

      {/* Front view */}
      <svg
        viewBox="0 0 200 320"
        width={size}
        height={size * 1.6}
        style={{ position: 'absolute', top: 0, left: 0 }}
      >
        {/* Body outline */}
        <ellipse cx="100" cy="42" rx="22" ry="22" fill="rgba(255,255,255,0.06)" stroke="rgba(255,255,255,0.15)" strokeWidth="0.8"/>

        {/* Neck */}
        <MuscleGroup id="neck" d="M90,60 L110,60 L108,75 L92,75 Z" />

        {/* Shoulders */}
        <MuscleGroup id="shoulders" d="M62,80 Q50,75 44,90 Q42,105 55,108 L74,100 Z" />
        <MuscleGroup id="shoulders" d="M138,80 Q150,75 156,90 Q158,105 145,108 L126,100 Z" />

        {/* Chest */}
        <MuscleGroup id="chest" d="M75,76 L92,74 L92,100 L75,104 Q68,98 68,86 Z" />
        <MuscleGroup id="chest" d="M125,76 L108,74 L108,100 L125,104 Q132,98 132,86 Z" />

        {/* Upper-back area shown via trapezoids */}
        <MuscleGroup id="traps" d="M80,62 L120,62 L125,78 L75,78 Z" />

        {/* Core / Abs */}
        <MuscleGroup id="core" d="M88,102 L112,102 L114,120 L86,120 Z" />
        <MuscleGroup id="core" d="M87,122 L113,122 L112,138 L88,138 Z" />

        {/* Biceps */}
        <MuscleGroup id="biceps" d="M55,110 L68,108 L66,134 L53,130 Z" />
        <MuscleGroup id="biceps" d="M145,110 L132,108 L134,134 L147,130 Z" />

        {/* Triceps (partially visible front) */}
        <MuscleGroup id="triceps" d="M44,110 L55,112 L53,134 L42,128 Z" />
        <MuscleGroup id="triceps" d="M156,110 L145,112 L147,134 L158,128 Z" />

        {/* Forearms */}
        <MuscleGroup id="forearms" d="M50,136 L63,132 L60,158 L47,152 Z" />
        <MuscleGroup id="forearms" d="M150,136 L137,132 L140,158 L153,152 Z" />

        {/* Hip flexors */}
        <MuscleGroup id="hip-flexors" d="M86,140 L100,138 L100,160 L86,162 Z" />
        <MuscleGroup id="hip-flexors" d="M114,140 L100,138 L100,160 L114,162 Z" />

        {/* Quads */}
        <MuscleGroup id="quads" d="M78,162 L98,158 L96,210 L74,208 Z" />
        <MuscleGroup id="quads" d="M122,162 L102,158 L104,210 L126,208 Z" />

        {/* Adductors */}
        <MuscleGroup id="adductors" d="M98,160 L102,160 L104,210 L96,210 Z" />

        {/* Calves (partially) */}
        <MuscleGroup id="calves" d="M78,212 L96,210 L94,252 L76,248 Z" />
        <MuscleGroup id="calves" d="M122,212 L104,210 L106,252 L124,248 Z" />

        {/* Knees */}
        <ellipse cx="87" cy="214" rx="9" ry="6" fill="rgba(255,255,255,0.05)" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5"/>
        <ellipse cx="113" cy="214" rx="9" ry="6" fill="rgba(255,255,255,0.05)" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5"/>

        {/* Glutes (front peek) */}
        <MuscleGroup id="glutes" d="M83,140 L100,138 L100,158 L82,162 Z" />
        <MuscleGroup id="glutes" d="M117,140 L100,138 L100,158 L118,162 Z" />

        {/* Lats visible from front */}
        <MuscleGroup id="lats" d="M65,80 L76,80 L74,110 L62,108 Z" />
        <MuscleGroup id="lats" d="M135,80 L124,80 L126,110 L138,108 Z" />

        {/* Center line detail */}
        <line x1="100" y1="74" x2="100" y2="140" stroke="rgba(255,255,255,0.08)" strokeWidth="0.6"/>
      </svg>

      {/* Muscle Legend */}
      {(primary.length > 0 || secondary.length > 0) && (
        <div style={{
          position: 'absolute',
          bottom: -40,
          left: 0, right: 0,
          display: 'flex', justifyContent: 'center', gap: 16,
          fontSize: 11,
          fontFamily: 'var(--font-heading)',
          letterSpacing: '0.05em',
        }}>
          {primary.length > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--crimson)' }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--crimson)', display: 'inline-block', boxShadow: '0 0 6px var(--crimson)' }}/>
              Primary
            </div>
          )}
          {secondary.length > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--teal)' }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--teal)', display: 'inline-block', boxShadow: '0 0 6px var(--teal)' }}/>
              Secondary
            </div>
          )}
        </div>
      )}
    </div>
  )
}
