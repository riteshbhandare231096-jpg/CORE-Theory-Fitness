import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useState } from 'react'

const NAV_LINKS = [
  { to: '/exercises',          label: 'Exercises' },
  { to: '/core-ai',            label: 'Core AI' },
  { to: '/coach',              label: 'AI Coach' },
  { to: '/nutrition-plus',     label: 'Nutrition+' },
  { to: '/dashboard/executive',label: 'Executive' },
  { to: '/avatar',             label: 'Avatar' },
  { to: '/dashboard/womens',   label: "Women's" },
  { to: '/dashboard/disabled', label: 'Adaptive' },
  { to: '/pricing',            label: 'Pricing' },
]

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const navigate = useNavigate()

  return (
    <header style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: 'rgba(8,8,15,0.85)',
      backdropFilter: 'blur(24px) saturate(180%)',
      WebkitBackdropFilter: 'blur(24px) saturate(180%)',
      borderBottom: '1px solid rgba(255,255,255,0.07)',
    }}>
      <nav style={{
        maxWidth: 1400, margin: '0 auto',
        padding: '0 24px',
        height: 60,
        display: 'flex', alignItems: 'center', gap: 0,
      }}>
        {/* Logo */}
        <Link to="/" style={{ textDecoration: 'none', flexShrink: 0, marginRight: 32 }}>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontSize: 15,
            fontWeight: 700,
            letterSpacing: '0.08em',
            color: 'var(--text)',
          }}>
            CORE <span style={{ color: 'var(--crimson)' }}>Theory</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="desktop-nav" style={{
          display: 'flex', alignItems: 'center', gap: 4, flex: 1,
          overflow: 'hidden',
        }}>
          {NAV_LINKS.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              style={({ isActive }) => ({
                textDecoration: 'none',
                padding: '5px 11px',
                borderRadius: 6,
                fontFamily: 'var(--font-heading)',
                fontSize: 12,
                fontWeight: 600,
                letterSpacing: '0.04em',
                whiteSpace: 'nowrap',
                color: isActive ? 'var(--crimson)' : 'rgba(238,238,248,0.55)',
                background: isActive ? 'rgba(229,25,62,0.08)' : 'transparent',
                border: isActive ? '1px solid rgba(229,25,62,0.2)' : '1px solid transparent',
                transition: 'all 0.15s ease',
              })}
            >
              {link.label}
            </NavLink>
          ))}
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginLeft: 16, flexShrink: 0 }}>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontSize: 9,
            letterSpacing: '0.1em',
            color: 'rgba(238,238,248,0.2)',
          }}>v5.0</span>

          <Link
            to="/auth"
            className="btn btn-ghost"
            style={{ padding: '7px 18px', fontSize: 11 }}
          >
            Sign in
          </Link>

          {/* Mobile hamburger */}
          <button
            className="mobile-menu-btn"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{
              display: 'none',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: 6,
              color: 'var(--text)',
            }}
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
              {menuOpen
                ? <path d="M4 4l12 12M4 16L16 4" stroke="currentColor" strokeWidth="1.5" fill="none"/>
                : <path d="M2 5h16M2 10h16M2 15h16" stroke="currentColor" strokeWidth="1.5" fill="none"/>
              }
            </svg>
          </button>
        </div>
      </nav>

      {/* Mobile dropdown */}
      {menuOpen && (
        <div style={{
          background: 'rgba(8,8,15,0.97)',
          borderBottom: '1px solid var(--glass-border)',
          padding: '12px 24px 20px',
          display: 'flex', flexDirection: 'column', gap: 4,
        }}>
          {NAV_LINKS.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={() => setMenuOpen(false)}
              style={({ isActive }) => ({
                textDecoration: 'none',
                padding: '10px 14px',
                borderRadius: 8,
                fontFamily: 'var(--font-heading)',
                fontSize: 13,
                fontWeight: 600,
                color: isActive ? 'var(--crimson)' : 'rgba(238,238,248,0.7)',
                background: isActive ? 'rgba(229,25,62,0.08)' : 'transparent',
              })}
            >
              {link.label}
            </NavLink>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 900px) {
          .desktop-nav { display: none !important; }
          .mobile-menu-btn { display: flex !important; }
        }
      `}</style>
    </header>
  )
}
