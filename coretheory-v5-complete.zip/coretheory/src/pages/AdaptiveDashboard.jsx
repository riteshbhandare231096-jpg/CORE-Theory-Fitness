import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../App'

const CATEGORIES_ADAPTIVE = [
  { key: 'all',         label: 'All', icon: '⭐' },
  { key: 'seated',      label: 'Seated',        icon: '🪑' },
  { key: 'low-impact',  label: 'Low-Impact',    icon: '🌊' },
  { key: 'upper-body',  label: 'Upper Body',    icon: '💪' },
  { key: 'core',        label: 'Core',          icon: '🎯' },
  { key: 'mobility',    label: 'Mobility',      icon: '🧘' },
]

const EXERCISES_ADAPTIVE = [
  // Seated
  { id:'se-1', name:'Seated Arm Raises', cat:'seated', duration:'5 min', level:'Beginner', muscles:['shoulders','traps'], desc:'Raise both arms forward and sideways — no equipment needed. Builds shoulder stability without axial loading.' },
  { id:'se-2', name:'Seated Chest Press', cat:'seated', duration:'8 min', level:'Beginner', muscles:['chest','triceps'], desc:'Use resistance bands anchored behind you. Pressing motion from a supported position.' },
  { id:'se-3', name:'Seated Row', cat:'seated', duration:'8 min', level:'Beginner', muscles:['lats','biceps'], desc:'Loop a band around a fixed point and perform a controlled rowing motion. Great for posture and back strength.' },
  { id:'se-4', name:'Seated Leg Extensions', cat:'seated', duration:'6 min', level:'Beginner', muscles:['quads'], desc:'Extend each leg at the knee, hold 2 sec. Builds quad strength without standing.' },
  { id:'se-5', name:'Chair Push-up', cat:'seated', duration:'8 min', level:'Intermediate', muscles:['chest','triceps'], desc:'Hands on armrests, push body up and lower. A regression of the full push-up.' },
  { id:'se-6', name:'Seated Shoulder Press', cat:'seated', duration:'8 min', level:'Intermediate', muscles:['shoulders','triceps'], desc:'Use light dumbbells or band resistance. Press overhead from a supported seated position.' },

  // Low-impact
  { id:'li-1', name:'Wall Push-up', cat:'low-impact', duration:'6 min', level:'Beginner', muscles:['chest','triceps'], desc:'Standing push-up against a wall. Zero impact on joints, full pressing pattern.' },
  { id:'li-2', name:'Standing Hip Abduction', cat:'low-impact', duration:'5 min', level:'Beginner', muscles:['glutes','abductors'], desc:'Lift one leg to the side while holding a wall. Builds hip stability without impact.' },
  { id:'li-3', name:'Heel Raises', cat:'low-impact', duration:'5 min', level:'Beginner', muscles:['calves'], desc:'Rise onto tiptoes slowly, lower. Excellent for circulation and calf strength.' },
  { id:'li-4', name:'Resistance Band Walk', cat:'low-impact', duration:'8 min', level:'Beginner', muscles:['glutes','abductors'], desc:'Band above knees, step side to side. Activates glutes without spinal loading.' },
  { id:'li-5', name:'Shallow Squat', cat:'low-impact', duration:'10 min', level:'Intermediate', muscles:['quads','glutes'], desc:'Squat to a partial range using a chair or box for safety. Builds leg strength progressively.' },
  { id:'li-6', name:'Step Tap', cat:'low-impact', duration:'8 min', level:'Beginner', muscles:['quads','calves'], desc:'Tap one foot on a low step and alternate. Low-intensity cardio without jumping.' },

  // Upper body
  { id:'ub-1', name:'Band Pull-Apart', cat:'upper-body', duration:'8 min', level:'Beginner', muscles:['rear-delts','rhomboids'], desc:'Hold a band and pull it apart horizontally. Critical for posture correction.' },
  { id:'ub-2', name:'Isometric Bicep Hold', cat:'upper-body', duration:'5 min', level:'Beginner', muscles:['biceps'], desc:'Press palms upward under a table. Zero movement, maximum muscle tension.' },
  { id:'ub-3', name:'Wrist Roller', cat:'upper-body', duration:'5 min', level:'Beginner', muscles:['forearms'], desc:'Roll a weighted dowel up and down to build forearm and grip endurance.' },
  { id:'ub-4', name:'Overhead Band Press', cat:'upper-body', duration:'10 min', level:'Intermediate', muscles:['shoulders','triceps'], desc:'Press a light band overhead from seated. Full shoulder range of motion.' },

  // Core
  { id:'co-1', name:'Seated Core Brace', cat:'core', duration:'5 min', level:'Beginner', muscles:['core'], desc:'Sit upright and draw the navel in. Hold 10 sec. The foundation of core re-engagement.' },
  { id:'co-2', name:'Dead Bug (Modified)', cat:'core', duration:'8 min', level:'Beginner', muscles:['core','hip-flexors'], desc:'Supine with knees bent, extend one arm overhead. Controlled movement, no floor arching.' },
  { id:'co-3', name:'Pallof Press (Band)', cat:'core', duration:'10 min', level:'Intermediate', muscles:['core','obliques'], desc:'Anti-rotation press with a resistance band anchored to the side. Best seated core exercise.' },
  { id:'co-4', name:'Seated Trunk Rotation', cat:'core', duration:'6 min', level:'Beginner', muscles:['obliques','core'], desc:'Hold a light weight and rotate the torso side to side from a seated position.' },

  // Mobility
  { id:'mo-1', name:'Neck Mobility Series', cat:'mobility', duration:'5 min', level:'Beginner', muscles:['neck','traps'], desc:'Controlled tilts and rotations for cervical decompression and range of motion.' },
  { id:'mo-2', name:'Shoulder Circles', cat:'mobility', duration:'4 min', level:'Beginner', muscles:['shoulders'], desc:'Large circular shoulder rolls forward and back. Lubricates the glenohumeral joint.' },
  { id:'mo-3', name:'Seated Hip Opener', cat:'mobility', duration:'6 min', level:'Beginner', muscles:['hips','glutes'], desc:'Cross ankle over opposite knee in a figure-4 position while seated. Deep piriformis stretch.' },
  { id:'mo-4', name:'Ankle Pumps', cat:'mobility', duration:'3 min', level:'Beginner', muscles:['ankles','calves'], desc:'Flex and point the feet repeatedly. Essential for circulation when seated for long periods.' },
  { id:'mo-5', name:'Wrist Flexor Stretch', cat:'mobility', duration:'3 min', level:'Beginner', muscles:['forearms'], desc:'Extend arm, gently press fingers back. Relieves typing and grip tension.' },
  { id:'mo-6', name:'Thoracic Extension', cat:'mobility', duration:'5 min', level:'Beginner', muscles:['spine','upper-back'], desc:'Hands behind head, gently extend over the back of a chair. Reverses kyphosis.' },
]

export default function AdaptiveDashboard() {
  const { user } = useAuth()
  const [activeCategory, setActiveCategory] = useState('all')
  const [breakCount, setBreakCount] = useState(0)

  const filtered = activeCategory === 'all'
    ? EXERCISES_ADAPTIVE
    : EXERCISES_ADAPTIVE.filter(e => e.cat === activeCategory)

  if (!user) {
    return (
      <div style={{ maxWidth:600, margin:'100px auto', padding:'0 24px', textAlign:'center' }}>
        <div style={{ fontSize:60, marginBottom:20 }}>♿</div>
        <h2 style={{ fontFamily:'var(--font-display)', fontSize:'1.8rem', fontWeight:700, marginBottom:12 }}>
          Adaptive Dashboard
        </h2>
        <p style={{ color:'var(--text-muted)', marginBottom:28, lineHeight:1.7 }}>
          Seated exercises, low-impact mobility, and adaptive routines designed for all abilities.
          Sign in with your verified adaptive athlete profile to access your personalized dashboard.
        </p>
        <Link to="/auth" className="btn btn-crimson">Sign In or Create Account</Link>
      </div>
    )
  }

  return (
    <div style={{ maxWidth:1200, margin:'0 auto', padding:'60px 40px 100px' }}>

      {/* Header */}
      <div style={{ marginBottom:48 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
          <span className="badge badge-teal" style={{ fontSize:9 }}>
            <span className="pulse-dot-teal" style={{ width:5, height:5 }}/>
            Adaptive Edition
          </span>
          {user.profile === 'disabled' && user.verified && (
            <span className="badge" style={{
              background:'rgba(74,222,128,0.1)', border:'1px solid rgba(74,222,128,0.2)',
              color:'#4ade80', fontSize:9,
            }}>
              ✓ ID Verified
            </span>
          )}
          {user && (
            <span style={{ fontSize:12, color:'var(--text-muted)' }}>
              Welcome back, <strong style={{ color:'var(--text)' }}>{user.name}</strong>
            </span>
          )}
        </div>
        <h1 style={{
          fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.8rem)',
          fontWeight:900, letterSpacing:'-0.02em', marginBottom:10,
        }}>
          Adaptive <span style={{ color:'var(--teal)' }}>Dashboard</span>
        </h1>
        <p style={{ fontSize:15, color:'var(--text-muted)', maxWidth:560 }}>
          Seated, low-impact, and adaptive exercises — engineered for every body, every ability.
        </p>
      </div>

      {/* Break tracker */}
      <div className="glass" style={{
        borderRadius:16, padding:'24px 28px', marginBottom:40,
        background:'rgba(0,212,212,0.05)', borderColor:'rgba(0,212,212,0.15)',
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:20 }}>
          <div>
            <div style={{ fontFamily:'var(--font-heading)', fontSize:13, fontWeight:700, marginBottom:4 }}>
              Sedentary Break Tracker
            </div>
            <div style={{ fontSize:18, fontFamily:'var(--font-display)', fontWeight:700, color:'var(--teal)' }}>
              Move every 45 min
            </div>
            <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:4 }}>
              {breakCount === 0 ? 'No break logged yet today.' : `${breakCount} break${breakCount > 1 ? 's' : ''} today · Keep going!`}
            </div>
          </div>
          <div style={{ display:'flex', gap:10, alignItems:'center' }}>
            <div style={{
              fontFamily:'var(--font-display)', fontSize:32, fontWeight:900,
              color:'var(--teal)', minWidth:40, textAlign:'center',
            }}>{breakCount}</div>
            <button
              className="btn btn-teal"
              onClick={() => setBreakCount(c => c + 1)}
              style={{ fontSize:12 }}
            >
              I just moved
            </button>
          </div>
        </div>
        <div style={{
          marginTop:16, fontSize:12, color:'rgba(238,238,248,0.45)', lineHeight:1.6,
        }}>
          💡 Seated for more than 45 minutes downregulates circulation and shortens hip flexors.
          Small movement breaks dramatically reduce these effects.
        </div>
      </div>

      {/* Category filters */}
      <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:32 }}>
        {CATEGORIES_ADAPTIVE.map(cat => {
          const isActive = activeCategory === cat.key
          return (
            <button
              key={cat.key}
              onClick={() => setActiveCategory(cat.key)}
              style={{
                padding:'8px 16px', borderRadius:8, cursor:'pointer',
                fontFamily:'var(--font-heading)', fontSize:12, fontWeight:700,
                border:'none', transition:'all 0.15s',
                background: isActive ? 'var(--teal)' : 'rgba(255,255,255,0.04)',
                color: isActive ? '#000' : 'rgba(238,238,248,0.55)',
                boxShadow: isActive ? '0 4px 16px rgba(0,212,212,0.3)' : 'none',
              }}
            >
              {cat.icon} {cat.label}
            </button>
          )
        })}
      </div>

      {/* Exercise grid */}
      <div style={{
        display:'grid',
        gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',
        gap:16, marginBottom:60,
      }}>
        {filtered.map(ex => (
          <div key={ex.id} className="glass card-lift" style={{ borderRadius:14, padding:'22px 22px' }}>
            <div style={{ display:'flex', gap:6, marginBottom:10 }}>
              <span className="tag" style={{ fontSize:10 }}>{ex.cat.replace('-', ' ')}</span>
              <span className={`badge diff-${ex.level.toLowerCase()}`} style={{ fontSize:9 }}>
                {ex.level}
              </span>
              <span style={{ marginLeft:'auto', fontSize:12, color:'var(--text-muted)' }}>{ex.duration}</span>
            </div>
            <h3 style={{ fontFamily:'var(--font-heading)', fontSize:15, fontWeight:700, marginBottom:8 }}>
              {ex.name}
            </h3>
            <p style={{ fontSize:13, lineHeight:1.6, color:'var(--text-muted)', marginBottom:14 }}>
              {ex.desc}
            </p>
            <div style={{ display:'flex', flexWrap:'wrap', gap:5 }}>
              {ex.muscles.map(m => (
                <span key={m} style={{
                  padding:'2px 8px', borderRadius:4, fontSize:11,
                  background:'rgba(0,212,212,0.08)', border:'1px solid rgba(0,212,212,0.18)',
                  color:'var(--teal)',
                }}>{m}</span>
              ))}
            </div>
            <button className="btn btn-ghost" style={{
              marginTop:14, fontSize:11, padding:'7px 14px',
              color:'var(--teal)', borderColor:'rgba(0,212,212,0.25)',
              width:'100%', justifyContent:'center',
            }}>
              Start Exercise →
            </button>
          </div>
        ))}
      </div>

      {/* Info card */}
      <div className="glass" style={{
        borderRadius:16, padding:'28px 32px',
        borderLeft:'3px solid var(--teal)',
      }}>
        <h3 style={{ fontFamily:'var(--font-heading)', fontSize:16, fontWeight:700, marginBottom:10 }}>
          About Adaptive Training
        </h3>
        <p style={{ fontSize:14, lineHeight:1.75, color:'rgba(238,238,248,0.65)' }}>
          Every exercise in this dashboard is designed to be performed safely with limited mobility,
          from a wheelchair, or with specific joint restrictions. Progress is tracked individually —
          your baseline is your baseline. Consult your physiotherapist before beginning any new program.
        </p>
      </div>
    </div>
  )
}
