import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../App'

const PROFILES = [
  {
    key: 'general',
    label: 'General Athlete',
    icon: '🏋️',
    desc: 'Full access to all calisthenics training programs and AI coaching.',
    color: 'var(--crimson)',
    glow: 'rgba(229,25,62,0.15)',
    border: 'rgba(229,25,62,0.3)',
  },
  {
    key: 'female',
    label: 'Female Athlete',
    icon: '💪',
    desc: 'Cycle-synced training, hormonal fitness guidance, and women-first programming.',
    color: '#e879f9',
    glow: 'rgba(232,121,249,0.12)',
    border: 'rgba(232,121,249,0.28)',
  },
  {
    key: 'disabled',
    label: 'Adaptive Athlete',
    icon: '♿',
    desc: 'Seated routines, low-impact mobility, and adaptive exercises. ID verification required.',
    color: 'var(--teal)',
    glow: 'rgba(0,212,212,0.1)',
    border: 'rgba(0,212,212,0.28)',
  },
]

export default function Auth() {
  const { setUser } = useAuth()
  const navigate = useNavigate()
  const [mode, setMode] = useState('login') // 'login' | 'signup'
  const [step, setStep] = useState(1) // 1=details, 2=profile, 3=id-upload (disabled only)
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [profile, setProfile] = useState('general')
  const [idFile, setIdFile] = useState(null)
  const [idPreview, setIdPreview] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const fileRef = useRef()

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const handleFileChange = (e) => {
    const f = e.target.files[0]
    if (!f) return
    setIdFile(f)
    const reader = new FileReader()
    reader.onload = ev => setIdPreview(ev.target.result)
    reader.readAsDataURL(f)
  }

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true); setError('')
    await new Promise(r => setTimeout(r, 900))
    // Demo: map email to profile
    const p = form.email.includes('female') ? 'female'
      : form.email.includes('disabled') || form.email.includes('adaptive') ? 'disabled'
      : 'general'
    const u = { name: form.name || 'Athlete', email: form.email, profile: p, verified: true }
    setUser(u)
    setLoading(false)
    redirectByProfile(p)
  }

  const handleSignupStep1 = (e) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.password) { setError('All fields required.'); return }
    setError('')
    setStep(2)
  }

  const handleProfileSelect = () => {
    if (profile === 'disabled') { setStep(3); return }
    completeSignup()
  }

  const handleIdUpload = () => {
    if (!idFile) { setError('Please upload your disability ID or certification card.'); return }
    setError('')
    completeSignup()
  }

  const completeSignup = async () => {
    setLoading(true)
    await new Promise(r => setTimeout(r, 1000))
    const u = { name: form.name, email: form.email, profile, verified: profile !== 'disabled' || !!idFile }
    setUser(u)
    setLoading(false)
    redirectByProfile(profile)
  }

  const redirectByProfile = (p) => {
    if (p === 'female')   return navigate('/dashboard/womens')
    if (p === 'disabled') return navigate('/dashboard/disabled')
    return navigate('/exercises')
  }

  const ProfileCard = ({ p }) => {
    const active = profile === p.key
    return (
      <button
        type="button"
        onClick={() => setProfile(p.key)}
        style={{
          background: active ? p.glow : 'rgba(255,255,255,0.03)',
          border: `1px solid ${active ? p.border : 'rgba(255,255,255,0.08)'}`,
          borderRadius: 14, padding: '20px 20px',
          cursor: 'pointer', textAlign: 'left',
          transition: 'all 0.2s ease',
          transform: active ? 'translateY(-2px)' : 'none',
          boxShadow: active ? `0 8px 28px ${p.glow}` : 'none',
        }}
      >
        <div style={{ fontSize: 28, marginBottom: 10 }}>{p.icon}</div>
        <div style={{
          fontFamily: 'var(--font-heading)', fontSize: 14, fontWeight: 700,
          color: active ? p.color : 'var(--text)', marginBottom: 6,
        }}>{p.label}</div>
        <div style={{ fontSize: 12, lineHeight: 1.5, color: 'rgba(238,238,248,0.5)' }}>{p.desc}</div>
        {p.key === 'disabled' && (
          <div style={{
            marginTop: 10, fontSize: 10, fontFamily: 'var(--font-heading)',
            fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase',
            color: active ? 'var(--teal)' : 'rgba(0,212,212,0.4)',
          }}>
            ID Verification Required
          </div>
        )}
        {active && (
          <div style={{
            position: 'absolute', top: 12, right: 12,
            width: 20, height: 20, borderRadius: '50%',
            background: p.color,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
              <path d="M2 5l2.5 2.5L8 3" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        )}
      </button>
    )
  }

  return (
    <div style={{
      minHeight: 'calc(100vh - 60px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '40px 24px',
    }}>
      <div style={{ width: '100%', maxWidth: mode === 'signup' && step === 2 ? 760 : 460 }}>

        {/* Card */}
        <div className="glass" style={{
          borderRadius: 20, padding: '44px 40px',
          boxShadow: '0 24px 80px rgba(0,0,0,0.5)',
        }}>

          {/* Logo */}
          <div style={{ textAlign: 'center', marginBottom: 36 }}>
            <div style={{
              fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700,
              letterSpacing: '0.08em', marginBottom: 6,
            }}>
              CORE <span style={{ color: 'var(--crimson)' }}>Theory</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>v5.0 · Glassmorphic Calisthenics OS</div>
          </div>

          {/* Mode toggle */}
          {step === 1 && (
            <div style={{
              display: 'flex', background: 'rgba(255,255,255,0.04)',
              borderRadius: 10, padding: 4, marginBottom: 32, border: '1px solid rgba(255,255,255,0.07)',
            }}>
              {['login', 'signup'].map(m => (
                <button
                  key={m}
                  onClick={() => { setMode(m); setError('') }}
                  style={{
                    flex: 1, padding: '9px 0',
                    borderRadius: 7, border: 'none', cursor: 'pointer',
                    fontFamily: 'var(--font-heading)', fontSize: 12, fontWeight: 700,
                    letterSpacing: '0.06em', textTransform: 'uppercase',
                    background: mode === m ? 'var(--crimson)' : 'transparent',
                    color: mode === m ? '#fff' : 'rgba(238,238,248,0.45)',
                    transition: 'all 0.2s',
                  }}
                >
                  {m === 'login' ? 'Sign In' : 'Create Account'}
                </button>
              ))}
            </div>
          )}

          {/* ── SIGN IN ── */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <input
                type="email" placeholder="Email address" required
                value={form.email} onChange={e => set('email', e.target.value)}
                style={{ width: '100%' }}
              />
              <input
                type="password" placeholder="Password" required
                value={form.password} onChange={e => set('password', e.target.value)}
                style={{ width: '100%' }}
              />
              {error && <div style={{ fontSize: 12, color: 'var(--crimson)' }}>{error}</div>}
              <button
                type="submit" className="btn btn-crimson"
                style={{ width: '100%', marginTop: 8, opacity: loading ? 0.7 : 1 }}
                disabled={loading}
              >
                {loading ? 'Signing in…' : 'Sign In'}
              </button>
              <div style={{
                fontSize: 12, textAlign: 'center', color: 'var(--text-muted)', marginTop: 8,
              }}>
                Demo: use any email. Include "female" or "disabled" to test those dashboards.
              </div>
            </form>
          )}

          {/* ── SIGN UP — STEP 1: Details ── */}
          {mode === 'signup' && step === 1 && (
            <form onSubmit={handleSignupStep1} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ fontSize: 14, fontFamily: 'var(--font-heading)', fontWeight: 700, marginBottom: 4 }}>
                Your details
              </div>
              <input
                placeholder="Full name" required
                value={form.name} onChange={e => set('name', e.target.value)}
                style={{ width: '100%' }}
              />
              <input
                type="email" placeholder="Email address" required
                value={form.email} onChange={e => set('email', e.target.value)}
                style={{ width: '100%' }}
              />
              <input
                type="password" placeholder="Password (min 8 chars)" required minLength={8}
                value={form.password} onChange={e => set('password', e.target.value)}
                style={{ width: '100%' }}
              />
              {error && <div style={{ fontSize: 12, color: 'var(--crimson)' }}>{error}</div>}
              <button type="submit" className="btn btn-crimson" style={{ width: '100%', marginTop: 8 }}>
                Continue →
              </button>
            </form>
          )}

          {/* ── SIGN UP — STEP 2: Profile ── */}
          {mode === 'signup' && step === 2 && (
            <div>
              <div style={{ marginBottom: 24 }}>
                <button
                  onClick={() => setStep(1)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer',
                    color: 'var(--text-muted)', fontSize: 12, fontFamily: 'var(--font-heading)',
                    padding: 0, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 4 }}
                >
                  ← Back
                </button>
                <div style={{ fontFamily: 'var(--font-heading)', fontSize: 15, fontWeight: 700, marginBottom: 6 }}>
                  Choose your athlete profile
                </div>
                <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                  This personalizes your dashboard and exercise programs.
                </div>
              </div>

              <div style={{
                display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px,1fr))',
                gap: 14, marginBottom: 28, position: 'relative',
              }}>
                {PROFILES.map(p => <ProfileCard key={p.key} p={p} />)}
              </div>

              <button
                onClick={handleProfileSelect}
                className="btn btn-crimson"
                style={{ width: '100%', opacity: loading ? 0.7 : 1 }}
                disabled={loading}
              >
                {loading ? 'Creating account…' : profile === 'disabled' ? 'Continue to Verification →' : 'Create Account'}
              </button>
            </div>
          )}

          {/* ── SIGN UP — STEP 3: ID Upload (disabled only) ── */}
          {mode === 'signup' && step === 3 && (
            <div>
              <button
                onClick={() => setStep(2)}
                style={{ background: 'none', border: 'none', cursor: 'pointer',
                  color: 'var(--text-muted)', fontSize: 12, fontFamily: 'var(--font-heading)',
                  padding: 0, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 4 }}
              >
                ← Back
              </button>

              {/* Header */}
              <div style={{
                display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8,
                padding: '12px 16px', borderRadius: 10,
                background: 'rgba(0,212,212,0.08)', border: '1px solid rgba(0,212,212,0.2)',
              }}>
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <path d="M9 2L10.5 6.5H15.5L11.5 9.5L13 14L9 11L5 14L6.5 9.5L2.5 6.5H7.5L9 2Z" stroke="var(--teal)" strokeWidth="1.2" fill="none"/>
                </svg>
                <span style={{ fontSize: 13, fontFamily: 'var(--font-heading)', fontWeight: 700, color: 'var(--teal)' }}>
                  Adaptive Athlete Verification
                </span>
              </div>

              <div style={{ fontSize: 13, lineHeight: 1.7, color: 'rgba(238,238,248,0.6)', marginBottom: 24 }}>
                To access your adaptive exercise dashboard, please upload a clear photo of your{' '}
                <strong style={{ color: 'var(--text)' }}>disability ID card or certification document</strong>.
                This is reviewed privately and only used to unlock your personalized programs.
              </div>

              {/* Upload zone */}
              <div
                onClick={() => fileRef.current?.click()}
                style={{
                  border: `2px dashed ${idFile ? 'rgba(0,212,212,0.5)' : 'rgba(255,255,255,0.14)'}`,
                  borderRadius: 14, padding: '32px 20px',
                  textAlign: 'center', cursor: 'pointer', marginBottom: 20,
                  background: idFile ? 'rgba(0,212,212,0.06)' : 'rgba(255,255,255,0.02)',
                  transition: 'all 0.2s',
                }}
              >
                <input
                  ref={fileRef} type="file"
                  accept="image/*,.pdf"
                  onChange={handleFileChange}
                  style={{ display: 'none' }}
                />
                {idPreview ? (
                  <div>
                    <img
                      src={idPreview} alt="ID preview"
                      style={{ maxHeight: 140, maxWidth: '100%', borderRadius: 8, marginBottom: 12, objectFit: 'contain' }}
                    />
                    <div style={{ fontSize: 12, color: 'var(--teal)', fontFamily: 'var(--font-heading)', fontWeight: 700 }}>
                      ✓ {idFile.name}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>Click to replace</div>
                  </div>
                ) : (
                  <div>
                    <div style={{ fontSize: 36, marginBottom: 12 }}>🪪</div>
                    <div style={{ fontSize: 14, fontFamily: 'var(--font-heading)', fontWeight: 700, marginBottom: 6 }}>
                      Upload Disability ID or Certificate
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                      JPG, PNG, or PDF · Click to browse
                    </div>
                  </div>
                )}
              </div>

              <div style={{
                fontSize: 11, color: 'rgba(238,238,248,0.35)', lineHeight: 1.6,
                marginBottom: 20, padding: '10px 14px', borderRadius: 8,
                background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)',
              }}>
                🔒 Your document is encrypted and stored securely. It is only used for one-time verification and never shared.
              </div>

              {error && <div style={{ fontSize: 12, color: 'var(--crimson)', marginBottom: 12 }}>{error}</div>}

              <button
                onClick={handleIdUpload}
                className="btn btn-teal"
                style={{ width: '100%', opacity: loading ? 0.7 : 1, fontSize: 13 }}
                disabled={loading}
              >
                {loading ? 'Verifying & creating account…' : 'Complete Verification & Join'}
              </button>
            </div>
          )}

        </div>

        {/* Step indicator for signup */}
        {mode === 'signup' && (
          <div style={{
            display: 'flex', justifyContent: 'center', gap: 8, marginTop: 20,
          }}>
            {[1, 2, profile === 'disabled' ? 3 : null].filter(Boolean).map(s => (
              <div key={s} style={{
                width: s === step ? 24 : 8, height: 8, borderRadius: 4,
                background: s <= step ? 'var(--crimson)' : 'rgba(255,255,255,0.1)',
                transition: 'all 0.3s ease',
              }}/>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
