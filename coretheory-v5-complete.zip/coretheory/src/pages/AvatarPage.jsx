export { AvatarPage as default } from './Misc'
