import { useState, useRef, useEffect } from 'react'

const QUICK_PROMPTS = [
  'Build me a 3-day push/pull/legs split',
  'Why does the core matter for a one-arm push-up?',
  'Macros for a 75 kg lean bulk',
  'How do I progress to my first muscle-up?',
]

const WELCOME_MSG = {
  role: 'assistant',
  content: 'Welcome to **CORE Theory**. I\'m your Pro-Coach. Ask me anything — programming, nutrition, form, recovery. Be specific and I\'ll give you a real answer.',
}

function renderMarkdown(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br/>')
}

export default function Coach() {
  const [messages, setMessages] = useState([WELCOME_MSG])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior:'smooth' })
  }, [messages])

  const sendMessage = async (text) => {
    const userMsg = text || input.trim()
    if (!userMsg || loading) return
    setInput('')

    const newMessages = [...messages, { role:'user', content:userMsg }]
    setMessages(newMessages)
    setLoading(true)

    try {
      const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY
      if (!apiKey || apiKey === 'your_anthropic_api_key_here') {
        // Demo mode — simulate a response
        await new Promise(r => setTimeout(r, 1200))
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `Great question on **${userMsg}**.\n\nTo enable live AI responses, add your Anthropic API key to the \`.env\` file:\n\n\`VITE_ANTHROPIC_API_KEY=sk-ant-...\`\n\nOnce set, I'll give you science-backed answers on training, nutrition, form, and recovery in real time.`,
        }])
        setLoading(false)
        return
      }

      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: JSON.stringify({
          model: 'claude-opus-4-6',
          max_tokens: 1024,
          system: `You are Pro-Coach AI 2.0 for CORE Theory — an elite calisthenics coaching platform. You are a world-class strength and conditioning coach specializing in bodyweight training, calisthenics progressions, sports nutrition, and movement science.

Tone: Direct, precise, and science-backed. No fluff. Real coaching.
Format: Use clear structure with bold for key terms. Keep responses focused and actionable. No excessive caveats.
Expertise: calisthenics progressions, bodyweight strength, pull-up & push-up progressions (up to one-arm and muscle-up), nutrition for athletes, injury prevention, mobility, core training science.`,
          messages: newMessages
            .filter(m => m.role !== 'system')
            .map(m => ({ role: m.role, content: m.content })),
        }),
      })

      const data = await res.json()
      const reply = data.content?.[0]?.text || 'Something went wrong. Please try again.'
      setMessages(prev => [...prev, { role:'assistant', content:reply }])
    } catch (err) {
      setMessages(prev => [...prev, {
        role:'assistant',
        content:'Connection error. Please check your API key in `.env` and try again.',
      }])
    }
    setLoading(false)
  }

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <div style={{
      maxWidth: 820, margin:'0 auto', padding:'40px 24px 0',
      height:'calc(100vh - 60px)', display:'flex', flexDirection:'column',
    }}>

      {/* Header */}
      <div style={{ marginBottom:28 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
          <span className="badge badge-teal" style={{ fontSize:9 }}>
            <span className="pulse-dot-teal" style={{ width:5, height:5 }}/>
            Pro-Coach AI 2.0
          </span>
        </div>
        <h1 style={{
          fontFamily:'var(--font-display)', fontSize:'clamp(1.6rem,4vw,2.2rem)',
          fontWeight:900, letterSpacing:'-0.02em', marginBottom:6,
        }}>
          Your Coach
        </h1>
        <p style={{ fontSize:13, color:'var(--text-muted)' }}>
          Science-backed answers on training, nutrition, and recovery.
        </p>
      </div>

      {/* Chat window */}
      <div
        className="glass"
        style={{
          flex:1, borderRadius:16, padding:'24px 20px',
          overflowY:'auto', display:'flex', flexDirection:'column', gap:16,
          minHeight:0, marginBottom:16,
        }}
      >
        {messages.map((msg, i) => (
          <div
            key={i}
            className={msg.role === 'user' ? 'anim-slide-right' : 'anim-fade-up'}
            style={{ animationDelay:`${i * 0.02}s` }}
          >
            {msg.role === 'assistant' ? (
              <div style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
                {/* Avatar */}
                <div style={{
                  width:32, height:32, borderRadius:'50%', flexShrink:0,
                  background:'linear-gradient(135deg, var(--teal) 0%, #007acc 100%)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontFamily:'var(--font-display)', fontSize:10, fontWeight:700, color:'#fff',
                  boxShadow:'0 0 12px rgba(0,212,212,0.4)',
                }}>
                  CT
                </div>
                <div>
                  <div style={{
                    fontSize:11, fontFamily:'var(--font-heading)', fontWeight:700,
                    color:'var(--teal)', marginBottom:6, letterSpacing:'0.05em',
                  }}>Coach</div>
                  <div
                    className="chat-coach"
                    dangerouslySetInnerHTML={{ __html: `<p>${renderMarkdown(msg.content)}</p>` }}
                    style={{ whiteSpace:'pre-wrap' }}
                  />
                </div>
              </div>
            ) : (
              <div style={{ display:'flex', justifyContent:'flex-end' }}>
                <div className="chat-user">{msg.content}</div>
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div style={{ display:'flex', gap:10, alignItems:'flex-start' }}>
            <div style={{
              width:32, height:32, borderRadius:'50%', flexShrink:0,
              background:'linear-gradient(135deg, var(--teal) 0%, #007acc 100%)',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'var(--font-display)', fontSize:10, color:'#fff',
            }}>CT</div>
            <div className="chat-coach" style={{ display:'flex', gap:5, alignItems:'center', padding:'14px 18px' }}>
              {[0,1,2].map(i => (
                <span key={i} style={{
                  width:6, height:6, borderRadius:'50%',
                  background:'var(--teal)', opacity:0.6,
                  animation:`pulse-dot 1.2s ${i*0.2}s infinite`,
                }}/>
              ))}
            </div>
          </div>
        )}
        <div ref={bottomRef}/>
      </div>

      {/* Quick prompts */}
      <div style={{
        display:'flex', flexWrap:'wrap', gap:8, marginBottom:12,
      }}>
        {QUICK_PROMPTS.map(p => (
          <button
            key={p}
            onClick={() => sendMessage(p)}
            disabled={loading}
            style={{
              padding:'6px 12px', borderRadius:6,
              background:'rgba(255,255,255,0.04)',
              border:'1px solid rgba(255,255,255,0.08)',
              color:'rgba(238,238,248,0.5)',
              fontSize:12, cursor:'pointer',
              fontFamily:'var(--font-body)',
              transition:'all 0.15s',
              opacity: loading ? 0.4 : 1,
            }}
          >
            {p}
          </button>
        ))}
      </div>

      {/* Input */}
      <div style={{ marginBottom:24 }}>
        <div style={{
          display:'flex', gap:10, alignItems:'flex-end',
          background:'rgba(255,255,255,0.04)',
          border:'1px solid rgba(255,255,255,0.1)',
          borderRadius:12, padding:'10px 14px',
        }}>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask your coach anything..."
            rows={1}
            style={{
              flex:1, background:'none', border:'none', resize:'none',
              color:'var(--text)', fontSize:14, lineHeight:1.5,
              fontFamily:'var(--font-body)', outline:'none',
              maxHeight:120, overflowY:'auto',
              padding:0,
            }}
          />
          <button
            onClick={() => sendMessage()}
            disabled={loading || !input.trim()}
            style={{
              width:36, height:36, borderRadius:8,
              background: loading || !input.trim() ? 'rgba(229,25,62,0.3)' : 'var(--crimson)',
              border:'none', cursor:'pointer',
              display:'flex', alignItems:'center', justifyContent:'center',
              transition:'all 0.2s', flexShrink:0,
            }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M2 8h12M9 4l5 4-5 4" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}
