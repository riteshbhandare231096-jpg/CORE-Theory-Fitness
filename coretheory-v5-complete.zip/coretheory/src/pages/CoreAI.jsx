const AI_EXERCISES = [
  { equipment: 'Machinery Adaptive Fitness', tool: 'Plate-loaded press', intensity: 'High', name: 'Hammer Strength Chest Press', sets: '4 × 8', cue: 'with controlled negatives. Squeeze at lockout.', muscles: ['chest', 'triceps'] },
  { equipment: 'Cable stack', tool: 'Cable stack', intensity: 'Moderate', name: 'Cable Lat Pulldown', sets: '3 × 12', cue: 'Pause at chin level, drive elbows down — not back.', muscles: ['lats', 'biceps'] },
  { equipment: 'Hack squat sled', tool: 'Hack squat sled', intensity: 'High', name: 'Plate-Loaded Hack Squat', sets: '3 × 10', cue: 'Foot position low for quad bias, high for glute bias.', muscles: ['quads', 'glutes'] },
  { equipment: 'Rope attachment', tool: 'Rope attachment', intensity: 'Low', name: 'Cable Face Pull', sets: '3 × 15', cue: 'Rotation cue: thumbs back, elbows high.', muscles: ['rear-delts', 'rhomboids'] },
  { equipment: 'Plate-loaded row', tool: 'Plate-loaded row', intensity: 'High', name: 'Iso-Lateral Row', sets: '3 × 10', cue: 'Single-arm work fixes left-right imbalance.', muscles: ['lats', 'mid-back'] },
  { equipment: 'Cable stack', tool: 'Cable stack', intensity: 'Moderate', name: 'Cable Triceps Pressdown', sets: '3 × 15', cue: 'Keep elbows pinned; finish with 30 sec iso-hold.', muscles: ['triceps'] },
]

const intensityColor = { High: 'var(--crimson)', Moderate: '#fbbf24', Low: 'var(--teal)' }
const intensityBg = { High: 'rgba(229,25,62,0.1)', Moderate: 'rgba(251,191,36,0.1)', Low: 'rgba(0,212,212,0.08)' }
const intensityBorder = { High: 'rgba(229,25,62,0.25)', Moderate: 'rgba(251,191,36,0.2)', Low: 'rgba(0,212,212,0.2)' }

export default function CoreAI() {
  return (
    <div style={{ maxWidth:1200, margin:'0 auto', padding:'60px 40px 100px' }}>
      {/* Header */}
      <div style={{ marginBottom:48 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
          <span className="badge badge-teal" style={{ fontSize:9 }}>Core AI</span>
        </div>
        <h1 style={{
          fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.8rem)',
          fontWeight:900, letterSpacing:'-0.02em', marginBottom:10,
        }}>
          Centralized intelligence hub
        </h1>
        <p style={{ fontSize:15, color:'var(--text-muted)', maxWidth:560 }}>
          Analyzes your profile and surfaces special exercises — mobility resets and
          high-intensity micro-workouts — calibrated to your goal and activity level.
        </p>
      </div>

      {/* Feature pills */}
      <div style={{ display:'flex', flexWrap:'wrap', gap:12, marginBottom:48 }}>
        {[
          { label:'Mobility-first', desc:'Joint health, range of motion, and posture reset.', color:'var(--teal)', bg:'rgba(0,212,212,0.08)', border:'rgba(0,212,212,0.2)' },
          { label:'HIIT micro-workouts', desc:'5–10 minute bursts that fit between meetings.', color:'var(--crimson)', bg:'rgba(229,25,62,0.08)', border:'rgba(229,25,62,0.2)' },
          { label:'Adaptive variations', desc:'Seated, single-limb, and low-impact substitutes.', color:'#e879f9', bg:'rgba(232,121,249,0.07)', border:'rgba(232,121,249,0.18)' },
        ].map(f => (
          <div key={f.label} style={{
            flex:'1 1 200px', padding:'20px 22px', borderRadius:12,
            background:f.bg, border:`1px solid ${f.border}`,
          }}>
            <div style={{ fontFamily:'var(--font-heading)', fontSize:13, fontWeight:700, color:f.color, marginBottom:6 }}>
              {f.label}
            </div>
            <div style={{ fontSize:12, color:'var(--text-muted)', lineHeight:1.5 }}>{f.desc}</div>
          </div>
        ))}
      </div>

      {/* Today's exercises */}
      <div style={{ marginBottom:48 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20 }}>
          <div>
            <div style={{ fontFamily:'var(--font-heading)', fontSize:16, fontWeight:700, marginBottom:4 }}>
              Today's special exercises
            </div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>Tuned for: maintain · moderate</div>
          </div>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))', gap:16 }}>
          {AI_EXERCISES.map(ex => (
            <div key={ex.name} className="glass card-lift" style={{ borderRadius:14, padding:'22px 22px' }}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
                <span style={{ fontSize:11, color:'var(--text-muted)' }}>{ex.tool}</span>
                <span style={{
                  padding:'2px 8px', borderRadius:4, fontSize:10,
                  fontFamily:'var(--font-heading)', fontWeight:700,
                  background: intensityBg[ex.intensity],
                  border: `1px solid ${intensityBorder[ex.intensity]}`,
                  color: intensityColor[ex.intensity],
                }}>{ex.intensity}</span>
              </div>
              <h3 style={{ fontFamily:'var(--font-heading)', fontSize:15, fontWeight:700, marginBottom:6 }}>
                {ex.name}
              </h3>
              <div style={{ fontSize:13, color:'rgba(238,238,248,0.55)', marginBottom:12, lineHeight:1.5 }}>
                <strong style={{ color:'var(--text)' }}>{ex.sets}</strong> {ex.cue}
              </div>
              <div style={{ display:'flex', flexWrap:'wrap', gap:5 }}>
                {ex.muscles.map(m => (
                  <span key={m} className="tag" style={{ fontSize:10 }}>{m}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Universal access */}
      <div className="glass" style={{
        borderRadius:16, padding:'28px 32px',
        borderLeft:'3px solid var(--teal)',
      }}>
        <div style={{ fontFamily:'var(--font-heading)', fontSize:14, fontWeight:700, marginBottom:6 }}>
          Universal Access
        </div>
        <div style={{ fontSize:13, color:'var(--text-muted)' }}>
          Inclusive routines for every athlete — adaptive, seated, and low-impact variations available for every exercise in this hub.
        </div>
      </div>
    </div>
  )
}
