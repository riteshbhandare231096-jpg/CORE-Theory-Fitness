import { useParams, Link } from 'react-router-dom'
import { useState } from 'react'
import { getExerciseById } from '../data/exercises'
import MuscleAvatar from '../components/MuscleAvatar'

export default function ExerciseDetail() {
  const { id } = useParams()
  const ex = getExerciseById(id)
  const [isPlaying, setIsPlaying] = useState(false)

  if (!ex) {
    return (
      <div style={{ textAlign:'center', padding:'120px 40px' }}>
        <p style={{ color:'var(--text-muted)' }}>Exercise not found.</p>
        <Link to="/exercises" className="btn btn-ghost" style={{ marginTop:20 }}>← Back to library</Link>
      </div>
    )
  }

  const handleListen = () => {
    if ('speechSynthesis' in window) {
      setIsPlaying(true)
      const text = [
        `${ex.name}.`,
        ex.description,
        'Coaching cues:',
        ...ex.cues,
      ].join(' ')
      const utt = new SpeechSynthesisUtterance(text)
      utt.rate = 0.9
      utt.pitch = 1
      utt.onend = () => setIsPlaying(false)
      window.speechSynthesis.cancel()
      window.speechSynthesis.speak(utt)
    }
  }

  const stopNarration = () => {
    window.speechSynthesis.cancel()
    setIsPlaying(false)
  }

  return (
    <div style={{ maxWidth:1200, margin:'0 auto', padding:'60px 40px 100px' }}>
      {/* Back */}
      <Link
        to="/exercises"
        style={{
          display:'inline-flex', alignItems:'center', gap:6,
          fontSize:13, color:'rgba(238,238,248,0.45)',
          textDecoration:'none', fontFamily:'var(--font-heading)',
          fontWeight:600, marginBottom:40,
          transition:'color 0.2s',
        }}
        onMouseEnter={e=>e.target.style.color='var(--text)'}
        onMouseLeave={e=>e.target.style.color='rgba(238,238,248,0.45)'}
      >
        ← Back to library
      </Link>

      <div style={{
        display:'grid',
        gridTemplateColumns:'1fr 1.4fr',
        gap:60,
        alignItems:'start',
      }}
      className="detail-grid"
      >
        <style>{`
          @media(max-width:768px) {
            .detail-grid { grid-template-columns:1fr !important; }
          }
        `}</style>

        {/* Left — Avatar */}
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center' }}>
          <div className="glass" style={{
            borderRadius:20, padding:40,
            display:'flex', flexDirection:'column', alignItems:'center',
            marginBottom:16,
          }}>
            <MuscleAvatar
              primary={ex.primary}
              secondary={ex.secondary}
              size={240}
            />
          </div>
          <p style={{
            fontSize:12, color:'var(--text-muted)', textAlign:'center',
            lineHeight:1.6, maxWidth:280,
            fontFamily:'var(--font-body)',
          }}>
            Crimson glow marks primary engagement; teal marks secondary stabilizers.
            Tap Listen for step-by-step coaching.
          </p>
        </div>

        {/* Right — Info */}
        <div>
          {/* Category badge */}
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:16 }}>
            <span className="badge badge-white" style={{ fontSize:10 }}>
              {ex.categoryLabel}
            </span>
            <span className={`badge diff-${ex.difficulty}`} style={{ fontSize:10 }}>
              {ex.difficulty}
            </span>
            {ex.premium && (
              <span className="badge badge-premium" style={{ fontSize:10 }}>Premium</span>
            )}
          </div>

          {/* Name */}
          <h1 style={{
            fontFamily:'var(--font-display)', fontSize:'clamp(1.6rem,3vw,2.4rem)',
            fontWeight:900, letterSpacing:'-0.02em', lineHeight:1.1, marginBottom:20,
          }}>
            {ex.name}
          </h1>

          {/* Description */}
          <p style={{
            fontSize:15, lineHeight:1.8, color:'rgba(238,238,248,0.65)',
            marginBottom:32, borderLeft:'2px solid rgba(229,25,62,0.3)',
            paddingLeft:16,
          }}>
            {ex.description}
          </p>

          {/* Muscles */}
          <div className="glass" style={{ borderRadius:12, padding:'20px 24px', marginBottom:24 }}>
            <div style={{ fontFamily:'var(--font-heading)', fontSize:11, fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)', marginBottom:16 }}>
              Muscles
            </div>
            <div style={{ display:'flex', gap:24 }}>
              <div>
                <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:6 }}>Primary</div>
                <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                  {ex.primary.map(m => (
                    <span key={m} style={{
                      padding:'3px 10px', borderRadius:5, fontSize:12,
                      background:'rgba(229,25,62,0.12)', border:'1px solid rgba(229,25,62,0.25)',
                      color:'var(--crimson)', fontFamily:'var(--font-heading)', fontWeight:600,
                    }}>{m}</span>
                  ))}
                </div>
              </div>
              {ex.secondary.length > 0 && (
                <div>
                  <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:6 }}>Secondary</div>
                  <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
                    {ex.secondary.map(m => (
                      <span key={m} style={{
                        padding:'3px 10px', borderRadius:5, fontSize:12,
                        background:'rgba(0,212,212,0.1)', border:'1px solid rgba(0,212,212,0.22)',
                        color:'var(--teal)', fontFamily:'var(--font-heading)', fontWeight:600,
                      }}>{m}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Coach narration */}
          <div className="glass" style={{ borderRadius:12, padding:'20px 24px', marginBottom:24 }}>
            <div style={{
              display:'flex', alignItems:'center', justifyContent:'space-between',
              marginBottom:16,
            }}>
              <div style={{ fontFamily:'var(--font-heading)', fontSize:11, fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)' }}>
                Coach narration
              </div>
              <div style={{ fontSize:12, color:'var(--text-muted)' }}>
                Hear how to perform {ex.name}.
              </div>
            </div>
            {isPlaying ? (
              <button
                onClick={stopNarration}
                className="btn btn-ghost"
                style={{ fontSize:12, padding:'8px 18px', gap:6 }}
              >
                <span style={{
                  width:10, height:10, background:'var(--crimson)', display:'inline-block',
                  borderRadius:2,
                }}/>
                Stop
              </button>
            ) : (
              <button
                onClick={handleListen}
                className="btn btn-ghost"
                style={{ fontSize:12, padding:'8px 18px', gap:6 }}
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <circle cx="7" cy="7" r="6" stroke="rgba(238,238,248,0.4)" strokeWidth="1.2"/>
                  <path d="M5.5 5l4 2-4 2V5z" fill="rgba(238,238,248,0.7)"/>
                </svg>
                Listen
              </button>
            )}
          </div>

          {/* Coaching cues */}
          <div>
            <div style={{
              fontFamily:'var(--font-heading)', fontSize:11, fontWeight:700,
              letterSpacing:'0.08em', textTransform:'uppercase',
              color:'var(--text-muted)', marginBottom:14,
            }}>
              Coaching Cues
            </div>
            <ol style={{ listStyle:'none', padding:0, display:'flex', flexDirection:'column', gap:10 }}>
              {ex.cues.map((cue, i) => (
                <li key={i} style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
                  <span style={{
                    fontFamily:'var(--font-display)', fontSize:10, color:'var(--crimson)',
                    minWidth:24, paddingTop:2, opacity:0.8,
                  }}>
                    {String(i+1).padStart(2,'0')}
                  </span>
                  <span style={{ fontSize:14, lineHeight:1.65, color:'rgba(238,238,248,0.7)' }}>
                    {cue}
                  </span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  )
}
