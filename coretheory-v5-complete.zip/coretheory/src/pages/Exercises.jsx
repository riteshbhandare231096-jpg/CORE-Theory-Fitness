import { useState } from 'react'
import { Link } from 'react-router-dom'
import { EXERCISES, CATEGORIES } from '../data/exercises'

function DiffBadge({ diff }) {
  return (
    <span className={`badge diff-${diff}`} style={{ fontSize:9, padding:'2px 7px' }}>
      {diff}
    </span>
  )
}

function ExerciseCard({ ex }) {
  return (
    <Link
      to={`/exercise/${ex.id}`}
      style={{ textDecoration:'none', color:'inherit', display:'block' }}
    >
      <div className="glass card-lift" style={{
        borderRadius: 14, padding: '20px 20px 18px',
        cursor: 'pointer', height: '100%',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Premium overlay */}
        {ex.premium && (
          <div style={{
            position: 'absolute', top: 10, right: 10,
          }}>
            <span className="badge badge-premium" style={{ fontSize:9 }}>Premium</span>
          </div>
        )}

        {/* Category */}
        <div style={{
          fontSize:9, fontFamily:'var(--font-heading)', fontWeight:700,
          letterSpacing:'0.1em', textTransform:'uppercase',
          color:'rgba(238,238,248,0.35)', marginBottom:8,
        }}>
          {ex.categoryLabel}
        </div>

        {/* Demo pill */}
        <div style={{
          display:'inline-flex', alignItems:'center', gap:5,
          padding:'3px 9px', borderRadius:5,
          background:'rgba(255,255,255,0.04)',
          border:'1px solid rgba(255,255,255,0.08)',
          marginBottom:12,
        }}>
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
            <circle cx="5" cy="5" r="4.5" stroke="rgba(238,238,248,0.3)" strokeWidth="0.8"/>
            <path d="M4 3.5l3 1.5-3 1.5V3.5z" fill="rgba(238,238,248,0.4)"/>
          </svg>
          <span style={{ fontSize:9, color:'rgba(238,238,248,0.4)', fontFamily:'var(--font-heading)', fontWeight:600, letterSpacing:'0.08em' }}>Demo</span>
        </div>

        {/* Name */}
        <h3 style={{
          fontFamily:'var(--font-heading)', fontSize:15, fontWeight:700,
          lineHeight:1.3, marginBottom:12, paddingRight: ex.premium ? 60 : 0,
        }}>
          {ex.name}
        </h3>

        {/* Muscle tags */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:5, marginBottom:10 }}>
          {[...ex.primary, ...ex.secondary].map(m => (
            <span key={m} className="tag" style={{ fontSize:10 }}>{m}</span>
          ))}
        </div>

        {/* Difficulty */}
        <DiffBadge diff={ex.difficulty} />

        {/* Lock overlay for premium */}
        {ex.premium && (
          <div style={{
            position:'absolute', inset:0, borderRadius:14,
            background:'rgba(8,8,15,0.45)',
            display:'flex', alignItems:'center', justifyContent:'center',
            backdropFilter:'blur(1px)',
            opacity:0,
            transition:'opacity 0.2s',
          }}
          className="premium-lock"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <rect x="5" y="11" width="14" height="10" rx="2" stroke="rgba(255,180,0,0.8)" strokeWidth="1.5"/>
              <path d="M8 11V7a4 4 0 018 0v4" stroke="rgba(255,180,0,0.8)" strokeWidth="1.5"/>
            </svg>
          </div>
        )}
      </div>
    </Link>
  )
}

export default function Exercises() {
  const [activeCategory, setActiveCategory] = useState('all')

  const filtered = activeCategory === 'all'
    ? EXERCISES
    : EXERCISES.filter(e => e.category === activeCategory)

  return (
    <div style={{ maxWidth:1400, margin:'0 auto', padding:'60px 40px 100px' }}>
      <style>{`
        .premium-lock:hover { opacity: 1 !important; }
        .exercise-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
          gap: 16px;
        }
        @media(max-width:600px) {
          .exercise-grid { grid-template-columns: 1fr 1fr; }
        }
      `}</style>

      {/* Header */}
      <div style={{ marginBottom:40 }}>
        <h1 style={{
          fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.8rem)',
          fontWeight:900, letterSpacing:'-0.02em', marginBottom:8,
        }}>
          Exercise Library
        </h1>
        <p style={{ fontSize:14, color:'var(--text-muted)' }}>
          {EXERCISES.length} movements · Premium movements locked
        </p>
      </div>

      {/* Category filters */}
      <div style={{
        display:'flex', flexWrap:'wrap', gap:8, marginBottom:40,
      }}>
        {CATEGORIES.map(cat => {
          const isActive = activeCategory === cat.key
          return (
            <button
              key={cat.key}
              onClick={() => setActiveCategory(cat.key)}
              style={{
                padding:'8px 18px',
                borderRadius:8,
                fontFamily:'var(--font-heading)',
                fontSize:12,
                fontWeight:700,
                letterSpacing:'0.04em',
                cursor:'pointer',
                border:'none',
                transition:'all 0.15s ease',
                background: isActive ? 'var(--crimson)' : 'var(--glass)',
                color: isActive ? '#fff' : 'rgba(238,238,248,0.55)',
                boxShadow: isActive ? '0 4px 16px rgba(229,25,62,0.3)' : 'none',
              }}
            >
              {cat.label}
            </button>
          )
        })}
      </div>

      {/* Grid */}
      <div className="exercise-grid">
        {filtered.map(ex => (
          <ExerciseCard key={ex.id} ex={ex} />
        ))}
      </div>

      {/* Premium CTA */}
      <div className="glass" style={{
        marginTop:60, borderRadius:16, padding:'40px 48px',
        textAlign:'center',
        background:'linear-gradient(135deg, rgba(229,25,62,0.06) 0%, rgba(0,212,212,0.04) 100%)',
        borderColor:'rgba(229,25,62,0.15)',
      }}>
        <div style={{
          fontFamily:'var(--font-display)', fontSize:11,
          letterSpacing:'0.15em', color:'var(--crimson)',
          marginBottom:12, textTransform:'uppercase',
        }}>Premium Access</div>
        <h2 style={{ fontFamily:'var(--font-heading)', fontSize:'1.6rem', fontWeight:800, marginBottom:12 }}>
          Unlock all advanced movements
        </h2>
        <p style={{ fontSize:14, color:'var(--text-muted)', marginBottom:28, maxWidth:460, margin:'0 auto 28px' }}>
          Get access to Archer Push-ups, Muscle-ups, Pistol Squats, Dragon Flags, and more.
        </p>
        <Link to="/pricing" className="btn btn-crimson">View Pricing →</Link>
      </div>
    </div>
  )
}
