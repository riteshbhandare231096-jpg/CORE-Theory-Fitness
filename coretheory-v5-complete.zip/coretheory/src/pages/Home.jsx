import { Link } from 'react-router-dom'

const FEATURES = [
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <circle cx="14" cy="10" r="6" fill="none" stroke="#e5193e" strokeWidth="1.5"/>
        <ellipse cx="14" cy="21" rx="8" ry="5" fill="none" stroke="#e5193e" strokeWidth="1.5"/>
        <circle cx="14" cy="10" r="3" fill="rgba(229,25,62,0.25)"/>
        <circle cx="14" cy="10" r="3" fill="rgba(229,25,62,0.25)" style={{animation:'muscleGlow2 2s ease-in-out infinite'}}/>
      </svg>
    ),
    title: 'Avatar Muscle-Glow',
    body: 'Primary muscles glow crimson; secondary glow teal. Every rep, visualized.',
    accent: 'var(--crimson)',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <rect x="3" y="5" width="22" height="18" rx="3" stroke="#00d4d4" strokeWidth="1.5"/>
        <path d="M8 11h5M8 15h10M8 19h7" stroke="#00d4d4" strokeWidth="1.2" strokeLinecap="round"/>
        <circle cx="21" cy="8" r="2.5" fill="#00d4d4" fillOpacity="0.3" stroke="#00d4d4" strokeWidth="1"/>
      </svg>
    ),
    title: 'Pro-Coach AI 2.0',
    body: 'Slate-gray chat. White text. No character cutoffs. Real coaching.',
    accent: 'var(--teal)',
  },
  {
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <path d="M14 3L17 9.5H24L18.5 13.5L20.5 20L14 16L7.5 20L9.5 13.5L4 9.5H11L14 3Z"
          fill="rgba(229,25,62,0.2)" stroke="#e5193e" strokeWidth="1.5" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Founder Override',
    body: "If you're the Founder, no locks, no UDID, no paywalls. Ever.",
    accent: 'var(--crimson)',
  },
]

const SCIENCE = [
  {
    num: '01',
    title: 'The Anatomy',
    body: 'The core comprises 29 pairs of muscles spanning the abdominals, paraspinals, gluteals, diaphragm, pelvic floor, and hip girdle — a corset that stabilizes the spine in three planes.',
  },
  {
    num: '02',
    title: 'The Function',
    body: 'Core stability is the ability to control trunk position and motion over the pelvis to allow optimal production, transfer, and control of force to the terminal segment in athletic activities.',
  },
  {
    num: '03',
    title: 'The Transfer',
    body: 'Every pull-up, pistol squat, and muscle-up depends on the kinetic chain. Without a stable core, force leaks before it reaches the limbs — strength becomes noise.',
  },
]

export default function Home() {
  return (
    <div>
      <style>{`
        @keyframes muscleGlow2 {
          0%,100% { opacity:0.3; } 50% { opacity:0.7; }
        }
        .hero-btn-row { display:flex; flex-wrap:wrap; gap:12px; align-items:center; }
        .stats-row { display:flex; flex-wrap:wrap; gap:2px; margin-top:48px; }
        .feature-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:20px; }
        .founder-grid { display:grid; grid-template-columns:1fr 1fr; gap:60px; align-items:center; }
        .science-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:20px; }
        @media(max-width:768px) {
          .founder-grid { grid-template-columns:1fr; }
        }
      `}</style>

      {/* ── HERO ── */}
      <section style={{
        minHeight: 'calc(100vh - 60px)',
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
        maxWidth: 1400, margin: '0 auto', padding: '80px 40px 60px',
      }}>
        <div style={{ maxWidth: 760 }}>
          {/* Version badge */}
          <div style={{ marginBottom: 28, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className="badge badge-crimson" style={{ fontSize: 9 }}>
              <span className="pulse-dot" style={{ width:6, height:6 }}/>
              v5.0 · Core Theory
            </span>
          </div>

          {/* Headline */}
          <h1 className="anim-fade-up" style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(2.4rem, 6vw, 5rem)',
            fontWeight: 900,
            lineHeight: 1.05,
            letterSpacing: '-0.02em',
            marginBottom: 28,
            color: 'var(--text)',
          }}>
            Forge the core<br/>
            <span style={{
              background: 'linear-gradient(135deg, var(--crimson) 0%, #ff6b6b 100%)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>of your strength.</span>
          </h1>

          {/* Sub */}
          <p className="anim-fade-up" style={{
            fontSize: 18, lineHeight: 1.7, color: 'rgba(238,238,248,0.55)',
            maxWidth: 560, marginBottom: 44,
            animationDelay: '0.1s',
          }}>
            An immersive, glassmorphic calisthenics OS. 80+ movements with a cartoon 3D
            avatar that lights up the muscles you train.
          </p>

          {/* CTAs */}
          <div className="hero-btn-row anim-fade-up" style={{ animationDelay: '0.2s' }}>
            <Link to="/exercises" className="btn btn-crimson">
              Enter the Library
            </Link>
            <Link to="/coach" className="btn btn-ghost">
              Ask the AI Coach
            </Link>
            <Link to="/auth" style={{
              fontSize: 13, color: 'rgba(238,238,248,0.4)',
              textDecoration: 'none', fontFamily: 'var(--font-heading)',
              letterSpacing: '0.04em', paddingLeft: 4,
            }}>
              Create account →
            </Link>
          </div>

          {/* Stats */}
          <div className="stats-row anim-fade-up" style={{ animationDelay: '0.3s' }}>
            {[
              { num: '80+',  label: 'Movements' },
              { num: '6',    label: 'Categories' },
              { num: '3D',   label: 'Avatar Engine' },
            ].map(s => (
              <div key={s.label} className="stat-box glass" style={{
                borderRadius: 10, margin: 4,
              }}>
                <span className="stat-number" style={{ fontSize: '1.6rem' }}>{s.num}</span>
                <span className="stat-label" style={{ fontSize: 10 }}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Video / Reel card */}
        <div className="anim-fade-up" style={{
          marginTop: 64, maxWidth: 480,
          animationDelay: '0.4s',
        }}>
          <div className="glass" style={{
            borderRadius: 14, padding: 20,
            display: 'flex', alignItems: 'center', gap: 16,
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: 10,
              background: 'rgba(229,25,62,0.12)',
              border: '1px solid rgba(229,25,62,0.25)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="9" stroke="var(--crimson)" strokeWidth="1.2"/>
                <path d="M8 7l6 3-6 3V7z" fill="var(--crimson)"/>
              </svg>
            </div>
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
                <span className="pulse-dot"/>
                <span style={{ fontSize:10, fontFamily:'var(--font-heading)', fontWeight:700, letterSpacing:'0.1em', color:'var(--crimson)', textTransform:'uppercase' }}>Live Reel</span>
              </div>
              <div style={{ fontSize:13, color:'var(--text-muted)' }}>Founder reel — muscle-glow engine in motion.</div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section style={{ maxWidth: 1400, margin: '0 auto', padding: '80px 40px' }}>
        <div style={{ marginBottom: 48 }}>
          <div className="section-label" style={{ marginBottom: 12 }}>Platform Features</div>
          <h2 style={{ fontFamily:'var(--font-display)', fontSize: 'clamp(1.4rem,3vw,2rem)', fontWeight:700, letterSpacing:'-0.02em' }}>
            Built for serious athletes
          </h2>
        </div>

        <div className="feature-grid">
          {FEATURES.map(f => (
            <div key={f.title} className="glass card-lift" style={{ borderRadius: 16, padding: 32 }}>
              <div style={{
                width: 52, height: 52, borderRadius: 12,
                background: f.accent === 'var(--crimson)' ? 'rgba(229,25,62,0.1)' : 'rgba(0,212,212,0.08)',
                border: `1px solid ${f.accent === 'var(--crimson)' ? 'rgba(229,25,62,0.2)' : 'rgba(0,212,212,0.18)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                marginBottom: 20,
              }}>
                {f.icon}
              </div>
              <h3 style={{ fontFamily:'var(--font-heading)', fontSize:17, fontWeight:700, marginBottom:10 }}>
                {f.title}
              </h3>
              <p style={{ fontSize:14, lineHeight:1.65, color:'var(--text-muted)' }}>{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── FOUNDER ── */}
      <section style={{ maxWidth: 1400, margin: '0 auto', padding: '80px 40px' }}>
        <div className="glass" style={{ borderRadius: 20, padding: '60px 60px', overflow: 'hidden', position: 'relative' }}>
          <div style={{
            position: 'absolute', top: -80, right: -80,
            width: 320, height: 320, borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(229,25,62,0.07) 0%, transparent 70%)',
            pointerEvents: 'none',
          }}/>
          <div className="founder-grid">
            {/* Image */}
            <div style={{ textAlign: 'center' }}>
              <div style={{
                width: 180, height: 180,
                borderRadius: '50%',
                margin: '0 auto 20px',
                background: 'linear-gradient(135deg, rgba(229,25,62,0.2) 0%, rgba(0,212,212,0.1) 100%)',
                border: '2px solid rgba(229,25,62,0.3)',
                overflow: 'hidden',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <img
                  src="https://preview--coretheory.lovable.app/assets/founder-iQJw-7SZ.png"
                  alt="Founder of CORE Theory"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  onError={e => {
                    e.target.style.display = 'none'
                    e.target.parentNode.innerHTML = '<svg width="60" height="60" viewBox="0 0 60 60" fill="none"><circle cx="30" cy="22" r="14" fill="rgba(229,25,62,0.3)"/><ellipse cx="30" cy="52" rx="20" ry="12" fill="rgba(229,25,62,0.2)"/></svg>'
                  }}
                />
              </div>
              <div className="badge badge-crimson" style={{ display:'inline-flex' }}>
                <span className="pulse-dot" style={{width:5,height:5}}/>
                Founder
              </div>
              <div style={{ marginTop: 10, fontFamily:'var(--font-heading)', fontSize:14, fontWeight:700 }}>Meet the Founder</div>
            </div>

            {/* Text */}
            <div>
              <h2 style={{
                fontFamily:'var(--font-display)', fontSize:'clamp(1.4rem,2.5vw,1.9rem)',
                fontWeight:700, letterSpacing:'-0.02em', marginBottom:20, lineHeight:1.2,
              }}>
                Built by an athlete.<br/>
                <span style={{ color:'var(--crimson)' }}>Engineered for the body.</span>
              </h2>
              <p style={{ fontSize:15, lineHeight:1.8, color:'rgba(238,238,248,0.6)', marginBottom:28 }}>
                I'm the founder of CORE Theory — a calisthenics athlete, systems thinker, and
                lifelong student of human movement. I built this platform because every training
                app I tried treated the body as a checklist of reps. None of them showed me what
                was firing, why it mattered, or how the kinetic chain actually transferred force.
              </p>
              <p style={{ fontSize:15, lineHeight:1.8, color:'rgba(238,238,248,0.6)', marginBottom:32 }}>
                CORE Theory fuses 3D anatomy with strength training: a glowing avatar lights up
                the exact muscles you recruit, an AI coach explains the science in plain language,
                and Founder-tier access keeps the system honest — no locks, no compromises, just
                the work.
              </p>
              <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
                {['Calisthenics Athlete','Movement Systems','3D Anatomy','AI-Augmented Coaching'].map(tag => (
                  <span key={tag} className="tag">{tag}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── SCIENCE ── */}
      <section style={{ maxWidth: 1400, margin: '0 auto', padding: '80px 40px 120px' }}>
        <div style={{ textAlign:'center', marginBottom:60 }}>
          <div className="section-label" style={{ marginBottom:14 }}>The Science</div>
          <h2 style={{
            fontFamily:'var(--font-display)', fontSize:'clamp(1.4rem,3vw,2.2rem)',
            fontWeight:700, letterSpacing:'-0.02em', marginBottom:16,
          }}>
            Why we call it <span style={{ color:'var(--crimson)' }}>Core Theory</span>
          </h2>
          <p style={{ fontSize:15, color:'var(--text-muted)', maxWidth:540, margin:'0 auto', lineHeight:1.7 }}>
            The "core" isn't your six-pack. Peer-reviewed research defines it as the entire
            lumbo-pelvic-hip complex — the body's central force-transfer engine.
          </p>
        </div>

        <div className="science-grid" style={{ marginBottom:48 }}>
          {SCIENCE.map(s => (
            <div key={s.num} className="glass card-lift" style={{ borderRadius:16, padding:32 }}>
              <div style={{
                fontFamily:'var(--font-display)', fontSize:11,
                letterSpacing:'0.15em', color:'var(--crimson)',
                marginBottom:14, opacity:0.8,
              }}>{s.num}</div>
              <h3 style={{ fontFamily:'var(--font-heading)', fontSize:18, fontWeight:700, marginBottom:12 }}>
                {s.title}
              </h3>
              <p style={{ fontSize:14, lineHeight:1.7, color:'var(--text-muted)' }}>{s.body}</p>
            </div>
          ))}
        </div>

        {/* Research callout */}
        <div className="glass" style={{
          borderRadius:16, padding:'28px 36px',
          borderLeft:'3px solid var(--crimson)',
        }}>
          <h4 style={{ fontFamily:'var(--font-heading)', fontSize:16, fontWeight:700, marginBottom:10 }}>
            Why this matters for your training
          </h4>
          <p style={{ fontSize:14, lineHeight:1.75, color:'var(--text-muted)', marginBottom:14 }}>
            Kibler, Press &amp; Sciascia (2006) — published in <em>Sports Medicine</em> via the
            U.S. National Library of Medicine — established that core stability is the foundation
            of all athletic performance. Weak core control measurably increases injury risk and
            caps maximal power output in the limbs. CORE Theory is built on this principle:
            train the center, and the periphery follows.
          </p>
          <a
            href="https://pubmed.ncbi.nlm.nih.gov/16526831/"
            target="_blank"
            rel="noopener noreferrer"
            style={{ fontSize:13, color:'var(--teal)', textDecoration:'none', fontFamily:'var(--font-heading)', fontWeight:600 }}
          >
            Source: NIH / NCBI — Kibler et al. 2006 →
          </a>
        </div>
      </section>
    </div>
  )
}
