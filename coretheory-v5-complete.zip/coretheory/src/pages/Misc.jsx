import { useState } from 'react'
import { Link } from 'react-router-dom'

/* ── EXECUTIVE DASHBOARD ───────────────────────── */
const ROUTINES_EXEC = [
  { title:'Postural Reset', duration:'4 min', tag:'Posture', desc:'Wall angels, chin tucks, scapular squeezes — fits in office attire.' },
  { title:'Hip Flexor Release', duration:'3 min', tag:'Stretch', desc:'Standing lunge stretch + couch stretch at your desk.' },
  { title:'Office HIIT Blast', duration:'15 min', tag:'HIIT', desc:'Bodyweight circuit for after work — squats, push-ups, mountain climbers.' },
  { title:'Wrist & Forearm Flow', duration:'2 min', tag:'Recovery', desc:'Counter typing strain in 8 movements.' },
  { title:'Calf Pump Series', duration:'3 min', tag:'Stretch', desc:'Boost circulation between meetings — heel raises + ankle pumps.' },
  { title:'Glute Activation', duration:'5 min', tag:'Posture', desc:'Reverse the dormant-glute effect of long sitting.' },
  { title:'Lunch-Break Cardio', duration:'10 min', tag:'HIIT', desc:'Stair intervals or brisk walk loop — no shower needed.' },
  { title:'Evening Decompress', duration:'6 min', tag:'Recovery', desc:'Spinal mobility, child\'s pose, breathwork before bed.' },
]

const tagColor = { Posture:'rgba(229,25,62,0.12)', HIIT:'rgba(251,191,36,0.1)', Stretch:'rgba(0,212,212,0.1)', Recovery:'rgba(232,121,249,0.1)' }
const tagTextColor = { Posture:'var(--crimson)', HIIT:'#fbbf24', Stretch:'var(--teal)', Recovery:'#e879f9' }
const tagBorder = { Posture:'rgba(229,25,62,0.25)', HIIT:'rgba(251,191,36,0.2)', Stretch:'rgba(0,212,212,0.2)', Recovery:'rgba(232,121,249,0.2)' }

export function ExecutiveDashboard() {
  const [breaks, setBreaks] = useState(0)

  return (
    <div style={{ maxWidth:1200, margin:'0 auto', padding:'60px 40px 100px' }}>
      <div style={{ marginBottom:48 }}>
        <span className="badge badge-crimson" style={{ marginBottom:12, display:'inline-flex', fontSize:9 }}>Executive Vitality</span>
        <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.6rem)', fontWeight:900, letterSpacing:'-0.02em', marginBottom:10 }}>
          The 9-to-5 dashboard
        </h1>
        <p style={{ fontSize:15, color:'var(--text-muted)', maxWidth:560 }}>
          Posture, mobility, and quick HIIT designed for office attire and limited space — built for those navigating a desk-bound schedule.
        </p>
      </div>

      {/* Break tracker */}
      <div className="glass" style={{ borderRadius:16, padding:'24px 28px', marginBottom:40, borderLeft:'3px solid var(--crimson)' }}>
        <div style={{ fontFamily:'var(--font-heading)', fontSize:14, fontWeight:700, marginBottom:4 }}>Sedentary Break Tracker</div>
        <div style={{ fontFamily:'var(--font-display)', fontSize:22, fontWeight:700, color:'var(--crimson)', marginBottom:4 }}>Move every 50 min</div>
        <div style={{ fontSize:12, color:'var(--text-muted)', marginBottom:16 }}>{breaks === 0 ? 'No break logged yet today.' : `${breaks} break${breaks>1?'s':''} today · Great work.`}</div>
        <div style={{ display:'flex', alignItems:'center', gap:16 }}>
          <div style={{ fontFamily:'var(--font-display)', fontSize:28, fontWeight:900, color:'var(--crimson)', minWidth:32 }}>{breaks}</div>
          <button className="btn btn-crimson" style={{ fontSize:11 }} onClick={() => setBreaks(b=>b+1)}>I just moved</button>
          <button className="btn btn-ghost" style={{ fontSize:11 }}>Enable reminders</button>
        </div>
        <div style={{ marginTop:14, fontSize:12, color:'rgba(238,238,248,0.4)', lineHeight:1.65 }}>
          Sitting longer than 60 minutes downregulates glute activation, shortens hip flexors, and spikes cortisol. Two-minute breaks every hour reverse most of this.
        </div>
      </div>

      <div style={{ fontFamily:'var(--font-heading)', fontSize:14, fontWeight:700, marginBottom:6 }}>Office-friendly routines</div>
      <div style={{ fontSize:12, color:'var(--text-muted)', marginBottom:24 }}>Curated for desk environments, business attire, and tight calendars. &nbsp;2–15 min each</div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:16 }}>
        {ROUTINES_EXEC.map(r => (
          <div key={r.title} className="glass card-lift" style={{ borderRadius:14, padding:'22px 22px' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
              <span style={{
                padding:'2px 8px', borderRadius:4, fontSize:10,
                fontFamily:'var(--font-heading)', fontWeight:700,
                background:tagColor[r.tag], border:`1px solid ${tagBorder[r.tag]}`,
                color:tagTextColor[r.tag],
              }}>{r.tag}</span>
              <span style={{ fontSize:12, color:'var(--text-muted)' }}>{r.duration}</span>
            </div>
            <h3 style={{ fontFamily:'var(--font-heading)', fontSize:15, fontWeight:700, marginBottom:8 }}>{r.title}</h3>
            <p style={{ fontSize:13, lineHeight:1.6, color:'var(--text-muted)' }}>{r.desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ── PRICING ───────────────────────────────────── */
const PLANS = [
  { name:'Starter', price:'$39', period:'3mo', monthly:'$13.00', popular:false },
  { name:'Builder', price:'$69', period:'6mo', monthly:'$11.50', popular:true },
  { name:'Forger',  price:'$95', period:'9mo', monthly:'$10.56', popular:false },
  { name:'Vanguard',price:'$119',period:'12mo',monthly:'$9.92',  popular:false },
]

const FEATURES_PRICING = ['All 80+ exercises','Avatar muscle-glow','AI Pro-Coach access','Specialty dashboards']

export function Pricing() {
  return (
    <div style={{ maxWidth:900, margin:'0 auto', padding:'60px 40px 100px', textAlign:'center' }}>
      <span className="badge badge-premium" style={{ marginBottom:20, display:'inline-flex', fontSize:9 }}>Premium</span>
      <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.8rem)', fontWeight:900, letterSpacing:'-0.02em', marginBottom:10 }}>
        Premium
      </h1>
      <p style={{ fontSize:15, color:'var(--text-muted)', marginBottom:48 }}>
        Unlock every advanced movement and specialty dashboard.
      </p>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:16, marginBottom:40 }}>
        {PLANS.map(p => (
          <div key={p.name} className="glass card-lift" style={{
            borderRadius:16, padding:'28px 20px',
            position:'relative', overflow:'hidden',
            borderColor: p.popular ? 'rgba(255,180,0,0.35)' : undefined,
            background: p.popular ? 'rgba(255,180,0,0.05)' : undefined,
          }}>
            {p.popular && (
              <div style={{
                position:'absolute', top:12, right:12,
                fontSize:9, fontFamily:'var(--font-heading)', fontWeight:700,
                letterSpacing:'0.08em', textTransform:'uppercase',
                color:'#ffb400', background:'rgba(255,180,0,0.12)',
                border:'1px solid rgba(255,180,0,0.25)',
                padding:'2px 7px', borderRadius:4,
              }}>Most popular</div>
            )}
            <div style={{ fontFamily:'var(--font-heading)', fontSize:14, fontWeight:700, marginBottom:8 }}>{p.name}</div>
            <div style={{ fontFamily:'var(--font-display)', fontSize:'1.8rem', fontWeight:900, color:'var(--crimson)', lineHeight:1 }}>{p.price}</div>
            <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:4 }}>/{p.period}</div>
            <div style={{ fontSize:12, color:'rgba(238,238,248,0.5)', marginBottom:20 }}>{p.monthly} per month</div>
            <ul style={{ listStyle:'none', padding:0, textAlign:'left', display:'flex', flexDirection:'column', gap:7, marginBottom:20 }}>
              {FEATURES_PRICING.map(f => (
                <li key={f} style={{ fontSize:12, color:'rgba(238,238,248,0.65)', display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ color:'#4ade80' }}>✓</span> {f}
                </li>
              ))}
            </ul>
            <button className="btn btn-crimson" style={{ width:'100%', fontSize:11 }}>Upgrade</button>
          </div>
        ))}
      </div>
      <Link to="/exercises" style={{ fontSize:13, color:'var(--text-muted)', textDecoration:'none', fontFamily:'var(--font-heading)' }}>
        ← Back to library
      </Link>
    </div>
  )
}

/* ── AVATAR PAGE ──────────────────────────────── */
export function AvatarPage() {
  return (
    <div style={{ maxWidth:800, margin:'0 auto', padding:'60px 40px 100px' }}>
      <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.6rem)', fontWeight:900, letterSpacing:'-0.02em', marginBottom:10 }}>
        Your Avatar
      </h1>
      <p style={{ fontSize:15, color:'var(--text-muted)', marginBottom:40 }}>
        Upload a photo — we map it onto your 3D cartoon model. (v1: face texture; full photo→rigged avatar comes later.)
      </p>
      <div className="glass" style={{ borderRadius:16, padding:'40px', textAlign:'center', marginBottom:24 }}>
        <div style={{ fontSize:60, marginBottom:16 }}>🧍</div>
        <div style={{ fontSize:14, color:'var(--text-muted)', marginBottom:20 }}>Sign in to view your avatar</div>
        <Link to="/auth" className="btn btn-ghost">Sign in</Link>
      </div>
      <div className="glass" style={{ borderRadius:16, padding:'24px 28px' }}>
        <div style={{ fontFamily:'var(--font-heading)', fontSize:13, fontWeight:700, color:'#fbbf24', marginBottom:6 }}>Photo mapping</div>
        <p style={{ fontSize:13, lineHeight:1.7, color:'rgba(238,238,248,0.55)', marginBottom:12 }}>
          Upload photo
        </p>
        <div style={{
          borderRadius:10, padding:'14px 18px', fontSize:12, lineHeight:1.65,
          background:'rgba(255,180,0,0.07)', border:'1px solid rgba(255,180,0,0.2)',
          color:'rgba(238,238,248,0.6)',
        }}>
          <strong style={{ color:'#fbbf24' }}>Heads-up</strong> — True photo→rigged 3D characters require offline pipelines (e.g. MetaHuman, ReadyPlayer.me). In-browser, your photo is wrapped onto the cartoon avatar's face. Muscle glow uses the v1 stylized rig.
        </div>
      </div>
    </div>
  )
}
