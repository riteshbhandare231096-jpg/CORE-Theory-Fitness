import { useState } from 'react'

const MEALS = {
  low:  ['Greek yogurt parfait + berries (350 cal)', 'Grilled chicken + quinoa bowl (520 cal)', 'Salmon + roasted veg (480 cal)'],
  moderate: ['Oats + whey + banana (520 cal)', 'Turkey wrap + sweet potato (640 cal)', 'Steak + jasmine rice + greens (700 cal)'],
  high: ['Protein pancakes + eggs (700 cal)', 'Chicken pasta + parmesan (820 cal)', 'Salmon + rice + avocado (760 cal)', 'Casein + nut butter (300 cal)'],
}

function calcMacros({ weight, height, age, sex, activity, goal }) {
  const w = parseFloat(weight) || 75
  const h = parseFloat(height) || 175
  const a = parseFloat(age) || 28

  const bmr = sex === 'male'
    ? 10 * w + 6.25 * h - 5 * a + 5
    : 10 * w + 6.25 * h - 5 * a - 161

  const multipliers = { sedentary:1.2, light:1.375, moderate:1.55, active:1.725 }
  let tdee = bmr * (multipliers[activity] || 1.55)

  if (goal === 'lose') tdee -= 350
  if (goal === 'gain') tdee += 300

  const protein = Math.round(w * 1.7)
  const fat = Math.round((tdee * 0.25) / 9)
  const carbs = Math.round((tdee - protein * 4 - fat * 9) / 4)
  const hydration = Math.round(w * 35)

  return { calories: Math.round(tdee), protein, carbs, fat, hydration }
}

export default function NutritionPlus() {
  const [form, setForm] = useState({ weight:'75', height:'175', age:'28', sex:'male', activity:'moderate', goal:'maintain' })
  const [hydration, setHydration] = useState(0)
  const macros = calcMacros(form)
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const hPct = Math.min((hydration / macros.hydration) * 100, 100)

  return (
    <div style={{ maxWidth:1100, margin:'0 auto', padding:'60px 40px 100px' }}>
      {/* Header */}
      <div style={{ marginBottom:48 }}>
        <span className="badge badge-teal" style={{ marginBottom:12, display:'inline-flex', fontSize:9 }}>Nutritional Guide Plus</span>
        <h1 style={{ fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.6rem)', fontWeight:900, letterSpacing:'-0.02em', marginBottom:10 }}>
          Eat for the work you do
        </h1>
        <p style={{ fontSize:15, color:'var(--text-muted)' }}>
          Macro calculator, hydration tracker, and meal-prep blueprints tuned to a 9-5 schedule.
        </p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:32, alignItems:'start' }} className="nutrition-grid">
        <style>{`@media(max-width:768px){.nutrition-grid{grid-template-columns:1fr !important;}}`}</style>

        {/* Calculator */}
        <div className="glass" style={{ borderRadius:16, padding:'28px 28px' }}>
          <div style={{ fontFamily:'var(--font-heading)', fontSize:13, fontWeight:700, marginBottom:20 }}>Macro calculator</div>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {[
              { key:'weight', label:'Weight (kg)', type:'number' },
              { key:'height', label:'Height (cm)', type:'number' },
              { key:'age',    label:'Age',         type:'number' },
            ].map(f => (
              <div key={f.key}>
                <label style={{ fontSize:11, color:'var(--text-muted)', display:'block', marginBottom:4 }}>{f.label}</label>
                <input type={f.type} value={form[f.key]} onChange={e => set(f.key, e.target.value)} style={{ width:'100%' }}/>
              </div>
            ))}
            <div>
              <label style={{ fontSize:11, color:'var(--text-muted)', display:'block', marginBottom:4 }}>Sex</label>
              <select value={form.sex} onChange={e => set('sex', e.target.value)} style={{ width:'100%' }}>
                <option value="female">Female</option>
                <option value="male">Male</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize:11, color:'var(--text-muted)', display:'block', marginBottom:4 }}>Activity</label>
              <select value={form.activity} onChange={e => set('activity', e.target.value)} style={{ width:'100%' }}>
                <option value="sedentary">Sedentary</option>
                <option value="light">Light</option>
                <option value="moderate">Moderate</option>
                <option value="active">Active</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize:11, color:'var(--text-muted)', display:'block', marginBottom:4 }}>Goal</label>
              <select value={form.goal} onChange={e => set('goal', e.target.value)} style={{ width:'100%' }}>
                <option value="lose">Lose</option>
                <option value="maintain">Maintain</option>
                <option value="gain">Gain</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results */}
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <div style={{ fontFamily:'var(--font-heading)', fontSize:13, fontWeight:700, marginBottom:4 }}>Daily target</div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            {[
              { label:'Calories', val:macros.calories, unit:'kcal', color:'var(--crimson)' },
              { label:'Protein',  val:macros.protein,  unit:'g',    color:'var(--teal)' },
              { label:'Carbs',    val:macros.carbs,    unit:'g',    color:'#fbbf24' },
              { label:'Fat',      val:macros.fat,      unit:'g',    color:'#e879f9' },
            ].map(m => (
              <div key={m.label} className="glass" style={{ borderRadius:12, padding:'20px 18px', textAlign:'center' }}>
                <div style={{ fontFamily:'var(--font-display)', fontSize:'1.6rem', fontWeight:900, color:m.color }}>{m.val}</div>
                <div style={{ fontSize:10, color:'var(--text-muted)', marginTop:2 }}>{m.unit} {m.label}</div>
              </div>
            ))}
          </div>

          {/* Hydration */}
          <div className="glass" style={{ borderRadius:12, padding:'20px 20px' }}>
            <div style={{ fontFamily:'var(--font-heading)', fontSize:13, fontWeight:700, marginBottom:12 }}>Hydration</div>
            <div style={{ fontFamily:'var(--font-display)', fontSize:'1.4rem', fontWeight:700, color:'var(--teal)', marginBottom:12 }}>
              {hydration} / {macros.hydration} ml
            </div>
            <div style={{ background:'rgba(255,255,255,0.06)', borderRadius:6, height:8, marginBottom:12, overflow:'hidden' }}>
              <div style={{
                height:'100%', borderRadius:6,
                background:'linear-gradient(90deg, var(--teal), #00ffd4)',
                width:`${hPct}%`, transition:'width 0.4s ease',
              }}/>
            </div>
            <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:12 }}>
              Target based on bodyweight (35 ml/kg).
            </div>
            <button
              className="btn btn-teal"
              style={{ fontSize:12, padding:'8px 18px' }}
              onClick={() => setHydration(h => Math.min(h + 250, macros.hydration * 1.5))}
            >
              +250 ml
            </button>
          </div>
        </div>
      </div>

      {/* Meal prep */}
      <div style={{ marginTop:48 }}>
        <div style={{ fontFamily:'var(--font-heading)', fontSize:16, fontWeight:700, marginBottom:6 }}>9-5 Meal Prep</div>
        <div style={{ fontSize:13, color:'var(--text-muted)', marginBottom:24 }}>Tailored to the workout intensity of your scheduled session.</div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))', gap:16 }}>
          {[
            { key:'low', label:'Low (rest day, mobility)', color:'var(--teal)' },
            { key:'moderate', label:'Moderate (HIIT or strength)', color:'#fbbf24' },
            { key:'high', label:'High (advanced session)', color:'var(--crimson)' },
          ].map(i => (
            <div key={i.key} className="glass" style={{ borderRadius:14, padding:'22px 22px', borderTop:`2px solid ${i.color}` }}>
              <div style={{ fontFamily:'var(--font-heading)', fontSize:13, fontWeight:700, color:i.color, marginBottom:14 }}>{i.label}</div>
              <ul style={{ listStyle:'none', padding:0, display:'flex', flexDirection:'column', gap:8 }}>
                {MEALS[i.key].map(m => (
                  <li key={m} style={{ fontSize:13, color:'rgba(238,238,248,0.65)', paddingLeft:14, position:'relative' }}>
                    <span style={{ position:'absolute', left:0, color:i.color }}>·</span>
                    {m}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
