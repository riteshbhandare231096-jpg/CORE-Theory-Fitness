export { Pricing as default } from './Misc'
