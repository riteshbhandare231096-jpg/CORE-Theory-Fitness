import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../App'

const PHASES = [
  {
    name: 'Menstrual',
    days: 'Days 1–5',
    icon: '🌑',
    focus: 'Rest & gentle mobility',
    energy: 'Low',
    color: '#e879f9',
    glow: 'rgba(232,121,249,0.12)',
    exercises: [
      { name: 'Supine Hip Circles', duration: '5 min', cat: 'Mobility' },
      { name: 'Child\'s Pose Flow', duration: '8 min', cat: 'Recovery' },
      { name: 'Cat-Cow Breath', duration: '6 min', cat: 'Breathwork' },
      { name: 'Gentle Spinal Twist', duration: '5 min', cat: 'Stretch' },
    ],
    tip: 'Iron and B12 are depleted during this phase — prioritise leafy greens and lean protein.',
  },
  {
    name: 'Follicular',
    days: 'Days 6–13',
    icon: '🌒',
    focus: 'Strength & new skills',
    energy: 'Building',
    color: '#fbbf24',
    glow: 'rgba(251,191,36,0.12)',
    exercises: [
      { name: 'Push-up Progressions', duration: '20 min', cat: 'Strength' },
      { name: 'Pull-up Negatives', duration: '15 min', cat: 'Strength' },
      { name: 'Jump Squat Circuits', duration: '12 min', cat: 'Power' },
      { name: 'Hollow Body Hold', duration: '10 min', cat: 'Core' },
    ],
    tip: 'Oestrogen peaks here — your body is primed for skill acquisition and PR attempts.',
  },
  {
    name: 'Ovulatory',
    days: 'Days 14–17',
    icon: '🌕',
    focus: 'Peak performance & HIIT',
    energy: 'Peak',
    color: '#e5193e',
    glow: 'rgba(229,25,62,0.14)',
    exercises: [
      { name: 'Full HIIT Circuit', duration: '30 min', cat: 'HIIT' },
      { name: 'Muscle-up Attempts', duration: '20 min', cat: 'Skill' },
      { name: 'Pistol Squat Work', duration: '15 min', cat: 'Strength' },
      { name: 'Explosive Pull-ups', duration: '12 min', cat: 'Power' },
    ],
    tip: 'LH surge gives you the highest pain tolerance and fastest reaction time — use it.',
  },
  {
    name: 'Luteal',
    days: 'Days 18–28',
    icon: '🌘',
    focus: 'Moderate volume & recovery',
    energy: 'Declining',
    color: '#00d4d4',
    glow: 'rgba(0,212,212,0.1)',
    exercises: [
      { name: 'Bodyweight Circuits', duration: '20 min', cat: 'Strength' },
      { name: 'Yoga Flow', duration: '15 min', cat: 'Mobility' },
      { name: 'Plank Progressions', duration: '10 min', cat: 'Core' },
      { name: 'Foam Rolling', duration: '8 min', cat: 'Recovery' },
    ],
    tip: 'Progesterone raises body temperature — reduce volume 15–20% and hydrate extra.',
  },
]

const ROUTINES = [
  { title: 'Glute & Hamstring Focus', duration: '25 min', level: 'Intermediate', icon: '🍑', desc: 'Hip thrusts, Romanian hinge, split squats, and glute bridges.' },
  { title: 'Upper Body Sculpt', duration: '20 min', level: 'Beginner', icon: '💪', desc: 'Push-up variants, pike push-ups, diamond holds, and tricep dips.' },
  { title: 'Core & Pelvic Floor', duration: '15 min', level: 'All levels', icon: '🎯', desc: 'Dead bug, bird-dog, pallof press, and pelvic floor activation.' },
  { title: 'Full Body HIIT', duration: '30 min', level: 'Advanced', icon: '⚡', desc: 'Tabata-style circuits: burpees, jump squats, mountain climbers.' },
  { title: 'Mobility & Flexibility', duration: '20 min', level: 'All levels', icon: '🧘', desc: 'Hip flexor release, hamstring flows, thoracic rotation, and breathwork.' },
  { title: 'Postpartum Rebuild', duration: '15 min', level: 'Beginner', icon: '🌸', desc: 'Diaphragmatic breathing, gentle core reconnection, and pelvic stability.' },
]

export default function WomensDashboard() {
  const { user } = useAuth()
  const [activePhase, setActivePhase] = useState(1) // default: Follicular

  // If not authenticated or not female profile, show soft gate
  if (!user) {
    return (
      <div style={{ maxWidth:600, margin:'100px auto', padding:'0 24px', textAlign:'center' }}>
        <div style={{ fontSize:60, marginBottom:20 }}>💪</div>
        <h2 style={{ fontFamily:'var(--font-display)', fontSize:'1.8rem', fontWeight:700, marginBottom:12 }}>
          Women's Dashboard
        </h2>
        <p style={{ color:'var(--text-muted)', marginBottom:28, lineHeight:1.7 }}>
          Cycle-synced training, hormonal fitness guidance, and women-first programming.
          Sign in to access your personalized dashboard.
        </p>
        <Link to="/auth" className="btn btn-crimson">Sign In or Create Account</Link>
      </div>
    )
  }

  const phase = PHASES[activePhase]

  return (
    <div style={{ maxWidth:1200, margin:'0 auto', padding:'60px 40px 100px' }}>
      {/* Header */}
      <div style={{ marginBottom:48 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
          <span className="badge" style={{
            background:'rgba(232,121,249,0.1)', border:'1px solid rgba(232,121,249,0.25)',
            color:'#e879f9', fontSize:9,
          }}>
            Women's Edition
          </span>
          {user && (
            <span style={{ fontSize:12, color:'var(--text-muted)' }}>
              Welcome back, <strong style={{ color:'var(--text)' }}>{user.name}</strong>
            </span>
          )}
        </div>
        <h1 style={{
          fontFamily:'var(--font-display)', fontSize:'clamp(1.8rem,4vw,2.8rem)',
          fontWeight:900, letterSpacing:'-0.02em', marginBottom:10,
        }}>
          Women's <span style={{ color:'#e879f9' }}>Dashboard</span>
        </h1>
        <p style={{ fontSize:15, color:'var(--text-muted)', maxWidth:580 }}>
          Cycle-synced training rooted in hormonal science. Your program adapts to your body's natural rhythm.
        </p>
      </div>

      {/* Cycle Phase Selector */}
      <div style={{ marginBottom:40 }}>
        <div style={{
          fontSize:11, fontFamily:'var(--font-heading)', fontWeight:700,
          letterSpacing:'0.1em', textTransform:'uppercase',
          color:'var(--text-muted)', marginBottom:16,
        }}>
          Hormonal Phase Tracker
        </div>
        <div style={{ display:'flex', gap:12, flexWrap:'wrap', marginBottom:28 }}>
          {PHASES.map((p, i) => (
            <button
              key={p.name}
              onClick={() => setActivePhase(i)}
              style={{
                padding:'10px 20px', borderRadius:10, cursor:'pointer',
                fontFamily:'var(--font-heading)', fontSize:12, fontWeight:700,
                border:'none', transition:'all 0.2s',
                background: activePhase === i ? p.glow : 'rgba(255,255,255,0.04)',
                color: activePhase === i ? p.color : 'rgba(238,238,248,0.5)',
                boxShadow: activePhase === i ? `0 0 20px ${p.glow}` : 'none',
                borderBottom: activePhase === i ? `2px solid ${p.color}` : '2px solid transparent',
              }}
            >
              {p.icon} {p.name}
            </button>
          ))}
        </div>

        {/* Active phase detail */}
        <div className="glass" style={{
          borderRadius:16, padding:'28px 32px',
          borderLeft:`3px solid ${phase.color}`,
          background: phase.glow,
        }}>
          <div style={{ display:'flex', gap:32, flexWrap:'wrap', alignItems:'flex-start' }}>
            <div style={{ flex:'1 1 200px' }}>
              <div style={{
                fontFamily:'var(--font-display)', fontSize:22, fontWeight:900,
                color:phase.color, marginBottom:4,
              }}>{phase.icon} {phase.name} Phase</div>
              <div style={{ fontSize:12, color:'var(--text-muted)', marginBottom:12 }}>{phase.days}</div>
              <div style={{ display:'flex', gap:8, marginBottom:16 }}>
                <span className="tag">Focus: {phase.focus}</span>
                <span className="tag">Energy: {phase.energy}</span>
              </div>
              <div style={{
                fontSize:13, lineHeight:1.7, color:'rgba(238,238,248,0.65)',
                padding:'10px 14px', borderRadius:8,
                background:'rgba(255,255,255,0.04)',
                border:'1px solid rgba(255,255,255,0.07)',
              }}>
                💡 {phase.tip}
              </div>
            </div>
            <div style={{ flex:'1 1 240px' }}>
              <div style={{ fontSize:11, fontFamily:'var(--font-heading)', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)', marginBottom:12 }}>
                Recommended Exercises
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                {phase.exercises.map(ex => (
                  <div key={ex.name} style={{
                    display:'flex', alignItems:'center', justifyContent:'space-between',
                    padding:'10px 14px', borderRadius:8,
                    background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.07)',
                  }}>
                    <div>
                      <span style={{ fontSize:13, fontWeight:600 }}>{ex.name}</span>
                      <span className="tag" style={{ marginLeft:8, fontSize:10 }}>{ex.cat}</span>
                    </div>
                    <span style={{ fontSize:12, color:'var(--text-muted)' }}>{ex.duration}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Routines */}
      <div>
        <div style={{
          fontSize:11, fontFamily:'var(--font-heading)', fontWeight:700,
          letterSpacing:'0.1em', textTransform:'uppercase',
          color:'var(--text-muted)', marginBottom:20,
        }}>
          All Women's Routines
        </div>
        <div style={{
          display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:16,
        }}>
          {ROUTINES.map(r => (
            <div key={r.title} className="glass card-lift" style={{ borderRadius:14, padding:'24px 24px' }}>
              <div style={{ fontSize:32, marginBottom:12 }}>{r.icon}</div>
              <div style={{ display:'flex', gap:6, marginBottom:10 }}>
                <span className="tag" style={{ fontSize:10 }}>{r.level}</span>
                <span className="tag" style={{ fontSize:10 }}>{r.duration}</span>
              </div>
              <h3 style={{ fontFamily:'var(--font-heading)', fontSize:15, fontWeight:700, marginBottom:8 }}>
                {r.title}
              </h3>
              <p style={{ fontSize:13, lineHeight:1.6, color:'var(--text-muted)' }}>{r.desc}</p>
              <button className="btn btn-ghost" style={{
                marginTop:16, fontSize:11, padding:'7px 16px',
                color:'#e879f9', borderColor:'rgba(232,121,249,0.25)',
              }}>
                Start Routine →
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
